package nalix.flowerfoods.core.domain.gateway.core.service;

import nalix.flowerfoods.core.domain.gateway.core.CoreDomainGatewayCoreConfig;
import nalix.flowerfoods.core.domain.gateway.graphql.types.Supply;
import nalix.flowerfoods.core.domain.gateway.graphql.types.SupplyInput;
import nalix.flowerfoods.core.domain.gateway.graphql.types.UpdateSupplyInput;
import nalix.flowerfoods.supply.service.client.SupplyServiceClient;
import nalix.flowerfoods.supply.service.grpc.v1.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import static nalix.flowerfoods.core.domain.gateway.core.support.Converters.*;

@Service
public class SupplyService {
    private final Logger              log = LoggerFactory.getLogger(getClass());
    private final SupplyServiceClient supplyServiceClient;

    public SupplyService(CoreDomainGatewayCoreConfig coreDomainGatewayCoreConfig) {
        this.supplyServiceClient = coreDomainGatewayCoreConfig.supplyServiceClient();
    }

    public Supply fetchSupply(String uuid) {
        GetSupplyRequest getSupplyRequest = GetSupplyRequest.newBuilder()
                                                            .setId(uuid)
                                                            .build();
        GetSupplyResponse response = supplyServiceClient.getSupply(getSupplyRequest);

        return toSupply(response.getSupply());
    }

    public Supply[] fetchSupplies() {
        GetSuppliesRequest getSuppliesRequest = GetSuppliesRequest.newBuilder()
                                                                  .build();
        GetSuppliesResponse response = supplyServiceClient.getSupplies(getSuppliesRequest);

        return toSupplies(response);
    }

    public Supply createSupply(SupplyInput input) {
        CreateSupplyResponse response = supplyServiceClient
            .createSupply(toNewSupply(input));

        return toSupply(response.getSupply());
    }

    public Supply updateSupply(UpdateSupplyInput input) {
        GetSupplyRequest getSupplyRequest = GetSupplyRequest.newBuilder()
                                                            .setId(input.getId())
                                                            .build();
        SupplyDto supply = supplyServiceClient.getSupply(getSupplyRequest)
                                              .getSupply();
        if (supply == null) {
            throw new RuntimeException("Supply not found");
        }
        UpdateSupplyResponse response = supplyServiceClient
            .updateSupply(toUpdateSupply(input, supply));

        return toSupply(response.getSupply());
    }
}
