package nalix.flowerfoods.core.domain.gateway.core.support;

import com.google.protobuf.StringValue;
import nalix.flowerfoods.core.domain.gateway.graphql.types.*;
import nalix.flowerfoods.marketplace.service.grpc.v1.*;
import nalix.flowerfoods.supply.service.grpc.v1.GetSuppliesResponse;
import nalix.flowerfoods.supply.service.grpc.v1.SupplyDto;

import java.util.List;
import java.lang.Double;

public class Converters {

    private Converters() {
    }

    public static MarketplaceDto toNewMarketplace(ProductInput productInput) {
        return MarketplaceDto.newBuilder()
                             .setName(productInput.getName())
                             .setDescription(productInput.getDescription())
                             .setType(productInput.getType())
                             .setIsAvailable(productInput.getIsAvailable())
                             .setQuantity(productInput.getQuantity())
                             .setQuantityUnit(productInput.getQuantityUnit())
                             .setPrice(productInput.getPrice().floatValue())
                             .setOriginalPrice(productInput.getOriginalPrice().floatValue())
                             .setLatitude(productInput.getLatitude())
                             .setLongitude(productInput.getLongitude())
                             .setWasteProbability(productInput.getWasteProbability().floatValue())
                             .setLocation(productInput.getLocation())
                             .setAvailableDate(productInput.getAvailableDate())
                             .setPriceIncrease(productInput.getPrice_increase().floatValue())
                             .setRating(productInput.getRating().floatValue())
                             .addAllImages(productInput.getImages())
                             .setMinimumBid(productInput.getMinimumBid().floatValue())
                             .setReservePrice(productInput.getReservePrice().floatValue())
                             .setBidTimeframe(productInput.getBidTimeframe())
                             .addAllAllergens(productInput.getAllergens())
                             .setPriceUnit(productInput.getPriceUnit())
                             .setAutoPricing(productInput.getAutoPricing())
                             .setExpiryDate(productInput.getExpiry_date())
                             .build();
    }

    public static MarketplaceDto toUpdateMarketplace(UpdateProductInput input, MarketplaceDto marketplace) {
        MarketplaceDto.Builder builder = marketplace.toBuilder()
                                                    .setId(StringValue.of(input.getId()));
        if (input.getName() != null) {
            builder.setName(input.getName());
        }

        if (input.getDescription() != null) {
            builder.setDescription(input.getDescription());
        }

        if (input.getType() != null) {
            builder.setType(input.getType());
        }

        if (input.getIsAvailable() != null) {
            builder.setIsAvailable(input.getIsAvailable());
        }

        if (input.getQuantity() != null) {
            builder.setQuantity(input.getQuantity());
        }

        if (input.getQuantityUnit() != null) {
            builder.setQuantityUnit(input.getQuantityUnit());
        }

        if (input.getPrice() != null) {
            builder.setPrice(input.getPrice().floatValue());
        }

        if (input.getOriginalPrice() != null) {
            builder.setOriginalPrice(input.getOriginalPrice().floatValue());
        }

        if (input.getLatitude() != null) {
            builder.setLatitude(input.getLatitude());
        }

        if (input.getLongitude() != null) {
            builder.setLongitude(input.getLongitude());
        }

        if(input.getDistance() != null) {
            builder.setDistance(input.getDistance());
        }

        if (input.getWasteProbability() != null) {
            builder.setWasteProbability(input.getWasteProbability()
                                             .intValue());
        }

        if (input.getPurchaseBy() == null) {
            builder.setPurchasedBy("");
        } else {
            builder.setPurchasedBy(input.getPurchaseBy());
        }

        if(input.getPurchaseDate() == null) {
            builder.setPurchasedDate("");
        } else {
            builder.setPurchasedDate(input.getPurchaseDate());
        }

        if (input.getLocation() != null) {
            builder.setLocation(input.getLocation());
        }

        if (input.getAvailableDate() != null) {
            builder.setAvailableDate(input.getAvailableDate());
        }

        if (input.getPrice_increase() != null) {
            builder.setPriceIncrease(input.getPrice_increase().floatValue());
        }

        if (input.getRating() != null) {
            builder.setRating(input.getRating().floatValue());
        }

        if(input.getImages() != null) {
            builder.clearImages();
            builder.addAllImages(input.getImages());
        }

        if(input.getSku() != null) {
            builder.setSku(input.getSku());
        }

        if(input.getMinimumBid() != null) {
            builder.setMinimumBid(input.getMinimumBid().floatValue());
        }

        if(input.getReservePrice() != null) {
            builder.setReservePrice(input.getReservePrice().floatValue());
        }

        if(input.getBidTimeframe() != null) {
            builder.setBidTimeframe(input.getBidTimeframe());
        }

        if(input.getTotalBids() != null) {
            builder.setTotalBids(input.getTotalBids());
        }

        if(input.getHighestBid() != null) {
            builder.setHighestBid(input.getHighestBid().floatValue());
        }

        if(input.getBidderId() != null) {
            builder.setBidderId(input.getBidderId());
        }

        if(input.getAllergens() != null) {
            builder.clearAllergens();
            builder.addAllAllergens(input.getAllergens());
        }

        if(input.getPriceUnit() != null) {
            builder.setPriceUnit(input.getPriceUnit());
        }

        if(input.getAutoPricing() != null) {
            builder.setAutoPricing(input.getAutoPricing());
        }

        if(input.getExpiry_date() != null) {
            builder.setExpiryDate(input.getExpiry_date());
        }

        if(input.getStatus() != null){
            builder.setStatus(input.getStatus());
        }

        return builder.build();
    }

    public static Product toProduct(MarketplaceDto marketplace) {
        return Product.newBuilder()
                      .id(marketplace.getId()
                                     .getValue())
                      .name(marketplace.getName())
                      .description(marketplace.getDescription())
                      .type(marketplace.getType())
                      .isAvailable(marketplace.getIsAvailable())
                      .quantity(marketplace.getQuantity())
                      .quantityUnit(marketplace.getQuantityUnit())
                      .price(Double.valueOf(marketplace.getPrice()))
                      .originalPrice(Double.valueOf(marketplace.getOriginalPrice()))
                      .latitude(Double.valueOf(marketplace.getLatitude()))
                      .longitude(Double.valueOf(marketplace.getLongitude()))
                      .distance(marketplace.getDistance())
                      .wasteProbability(Double.valueOf(marketplace.getWasteProbability()))
                      .purchaseBy(marketplace.getPurchasedBy())
                      .purchaseDate(marketplace.getPurchasedDate())
                      .location(marketplace.getLocation())
                      .availableDate(marketplace.getAvailableDate())
                      .price_increase(Double.valueOf(marketplace.getPriceIncrease()))
                      .rating(Double.valueOf(marketplace.getRating()))
                      .images(marketplace.getImagesList())
                      .sku(marketplace.getSku())
                      .minimumBid(Double.valueOf(marketplace.getMinimumBid()))
                      .reservePrice(Double.valueOf(marketplace.getReservePrice()))
                      .bidTimeframe(marketplace.getBidTimeframe())
                      .totalBids(marketplace.getTotalBids())
                      .highestBid(Double.valueOf(marketplace.getHighestBid()))
                      .bidderId(marketplace.getBidderId())
                      .allergens(marketplace.getAllergensList())
                      .priceUnit(marketplace.getPriceUnit())
                      .autoPricing(marketplace.getAutoPricing())
                      .status(marketplace.getStatus())
                      .expiry_date(marketplace.getExpiryDate())
                      .build();
    }


    public static Product[] toProducts(GetMarketplacesResponse response) {
        List<MarketplaceDto> productList = response.getMarketplaceList();
        Product[] productsResponse = productList.stream()
                                                .map(Converters::toProduct)
                                                .toArray(Product[]::new);

        return productsResponse;
    }

    public static Account toAccount(AccountDto account) {
        return Account.newBuilder()
                      .id(account.getId()
                                     .getValue())
                      .name(account.getName())
                      .email(account.getEmail())
                      .image_url(account.getImageUrl())
                      .purchased_stat(Double.valueOf(account.getPurchasedStat()))
                      .money_saved_stat(Double.valueOf(account.getMoneySavedStat()))
                      .waste_saved_stat(Double.valueOf(account.getWasteSavedStat()))
                      .build();
    }

    public static Account[] toAccounts(GetAccountsResponse response) {
        List<AccountDto> accountList = response.getAccountList();
        Account[] accountsResponse = accountList.stream()
                                                .map(Converters::toAccount)
                                                .toArray(Account[]::new);

        return accountsResponse;
    }

    public static AccountDto toUpdateAccount(UpdateAccountInput input, AccountDto marketplace) {
        AccountDto.Builder builder = marketplace.toBuilder()
                                                .setId(StringValue.of(input.getId()));
        if (input.getName() != null) {
            builder.setName(input.getName());
        }
        if (input.getEmail() != null) {
            builder.setEmail(input.getEmail());
        }
        if (input.getImage_url() != null) {
            builder.setImageUrl(input.getImage_url());
        }
        if (input.getPurchased_stat() != null) {
            builder.setPurchasedStat(input.getPurchased_stat()
                                          .floatValue());
        }
        if (input.getMoney_saved_stat() != null) {
            builder.setMoneySavedStat(input.getMoney_saved_stat()
                                           .floatValue());
        }
        if (input.getWaste_saved_stat() != null) {
            builder.setWasteSavedStat(input.getWaste_saved_stat()
                                           .floatValue());
        }

        return builder.build();
    }

    public static SupplyDto toNewSupply(SupplyInput input) {
        SupplyDto supply = SupplyDto.newBuilder()
                                    .setName(input.getName())
                                    .build();
        return supply;
    }

    public static SupplyDto toUpdateSupply(UpdateSupplyInput input, SupplyDto supply) {
        SupplyDto.Builder builder = supply.toBuilder();
        if (input.getName() != null) {
            builder.setName(input.getName());
        }

        return builder.build();
    }

    public static Supply toSupply(SupplyDto supply) {
        return Supply.newBuilder()
                     .id(supply.getId()
                               .getValue())
                     .name(supply.getName())
                     .build();
    }

    public static Supply[] toSupplies(GetSuppliesResponse response) {
        List<SupplyDto> supplyList = response.getSupplyList();
        Supply[] suppliesResponse;
        suppliesResponse = supplyList.stream()
                                     .map(Converters::toSupply)
                                     .toArray(Supply[]::new);

        return suppliesResponse;
    }

    public static Ingredients toIngredients (GetIngredientsResponse getIngredientsResponse){
        return Ingredients.newBuilder()
                          .ingredients(getIngredientsResponse.getIngredientList())
                          .build();
    }
}
