package nalix.flowerfoods.core.domain.gateway.core;

import nalix.flowerfoods.core.domain.gateway.core.service.MarketplaceService;
import nalix.flowerfoods.core.domain.gateway.core.service.SupplyService;
import nalix.flowerfoods.core.domain.gateway.graphql.types.*;
import nalix.flowerfoods.marketplace.service.grpc.v1.GetIngredientsRequest;
import nalix.flowerfoods.marketplace.service.grpc.v1.GetIngredientsResponse;
import org.springframework.stereotype.Component;

@Component
public class CoreDomainGatewayCore {
    private final MarketplaceService marketplaceService;
    private final SupplyService      supplyService;

    public CoreDomainGatewayCore(MarketplaceService marketplaceService,
                                 SupplyService supplyService) {
        this.marketplaceService = marketplaceService;
        this.supplyService = supplyService;
    }

    public Product fetchProduct(String uuid) {
        return marketplaceService.fetchProduct(uuid);
    }

    public Product[] fetchProducts(String name,
                                   String type,
                                   Float account_latitude,
                                   Float account_longitude,
                                   String is_available,
                                   String sort_by,
                                   String sort_direction,
                                   Integer start_page,
                                   Integer page_size) {

        return marketplaceService.fetchProducts(name,
                                                type,
                                                account_latitude,
                                                account_longitude,
                                                is_available,
                                                sort_by,
                                                sort_direction,
                                                start_page,
                                                page_size);
    }

    public Product createProduct(ProductInput input) {
        return marketplaceService.createProduct(input);
    }

    public Product updateProduct(UpdateProductInput input) {
        return marketplaceService.updateProduct(input);
    }

    public Account fetchAccount(String uuid) {
        return marketplaceService.fetchAccount(uuid);
    }

    public Account[] fetchAccounts() {
        return marketplaceService.fetchAccounts();
    }

    public Account createAccount(AccountInput input) {
        return marketplaceService.createAccount(input);
    }

    public Account updateAccount(UpdateAccountInput input) {
        return marketplaceService.updateAccount(input);
    }

    public Supply fetchSupply(String uuid) {
        return supplyService.fetchSupply(uuid);
    }

    public Supply[] fetchSupplies() {
        return supplyService.fetchSupplies();
    }

    public Supply createSupply(SupplyInput input) {
        return supplyService.createSupply(input);
    }

    public Supply updateSupply(UpdateSupplyInput input) {
        return supplyService.updateSupply(input);
    }

    public Ingredients getIngredients (GetIngredientsInput input){
        return marketplaceService.getIngredients(input);
    }

    public Product deleteProduct(DeleteProductInput input) {
        return marketplaceService.deleteProduct(input);
    }
}
