package nalix.flowerfoods.core.domain.gateway.core.service;

import nalix.flowerfoods.core.domain.gateway.core.CoreDomainGatewayCoreConfig;
import nalix.flowerfoods.core.domain.gateway.core.support.Converters;
import nalix.flowerfoods.core.domain.gateway.graphql.types.*;
import nalix.flowerfoods.marketplace.service.client.MarketplaceServiceClient;
import nalix.flowerfoods.marketplace.service.grpc.v1.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import static nalix.flowerfoods.core.domain.gateway.core.support.Converters.*;

@Service
public class MarketplaceService {
    private final Logger                   log = LoggerFactory.getLogger(getClass());
    private final MarketplaceServiceClient marketplaceServiceClient;

    public MarketplaceService(CoreDomainGatewayCoreConfig coreDomainGatewayCoreConfig) {
        this.marketplaceServiceClient = coreDomainGatewayCoreConfig.marketplaceServiceClient();
    }

    public Product fetchProduct(String uuid) {
        GetMarketplaceRequest getMarketplaceRequest = GetMarketplaceRequest.newBuilder()
                                                                           .setId(uuid)
                                                                           .build();
        GetMarketplaceResponse response = marketplaceServiceClient.getMarketplace(getMarketplaceRequest);

        if (!response.hasMarketplace()) {
            throw new RuntimeException("Product not found");
        }

        return toProduct(response.getMarketplace());
    }

    public Product[] fetchProducts(String name,
                                   String type,
                                   Float account_latitude,
                                   Float account_longitude,
                                   String is_available,
                                   String sort_by,
                                   String sort_direction,
                                   Integer start_page,
                                   Integer page_size) {

        log.debug("Inside fetchProducts 1...");

        GetMarketplacesRequest getMarketplacesRequest = GetMarketplacesRequest.newBuilder()
                                                                              .setName(name)
                                                                              .setType(type)
                                                                              .setAccountLatitude(account_latitude)
                                                                              .setAccountLongitude(account_longitude)
                                                                              .setIsAvailable(is_available)
                                                                              .setSortBy(sort_by)
                                                                              .setSortDirection(sort_direction)
                                                                              .setStartPage(start_page)
                                                                              .setPageSize(page_size)
                                                                              .build();

        log.debug("Inside fetchProducts 2...");
        GetMarketplacesResponse response = marketplaceServiceClient.getMarketplaces(getMarketplacesRequest);

        log.debug("Inside fetchProducts 3...");
        return toProducts(response);
    }

    public Product createProduct(ProductInput input) {
        CreateMarketplaceResponse response = marketplaceServiceClient
            .createMarketplace(toNewMarketplace(input));

        return toProduct(response.getMarketplace());
    }

    public Product updateProduct(UpdateProductInput input) {
        MarketplaceDto marketplace = marketplaceServiceClient.getMarketplace(GetMarketplaceRequest.newBuilder()
                                                                                                  .setId(input.getId())
                                                                                                  .build())
                                                             .getMarketplace();
        if (marketplace == null) {
            throw new RuntimeException("Product not found");
        }
        UpdateMarketplaceResponse response = marketplaceServiceClient
            .updateMarketplace(toUpdateMarketplace(input, marketplace));


        return toProduct(response.getMarketplace());
    }

    public Account fetchAccount(String uuid) {
        GetAccountRequest request = GetAccountRequest.newBuilder()
                                                     .setId(uuid)
                                                     .build();
        GetAccountResponse response = marketplaceServiceClient.getAccount(request);

        if (!response.hasAccount()) {
            throw new RuntimeException("Account not found");
        }

        return toAccount(response.getAccount());
    }

    public Account[] fetchAccounts() {
        GetAccountsRequest request = GetAccountsRequest.newBuilder()
                                                       .build();
        GetAccountsResponse response = marketplaceServiceClient.getAccounts(request);

        return toAccounts(response);
    }

    public Account createAccount(AccountInput input) {
        CreateAccountResponse response = marketplaceServiceClient
            .createAccount(AccountDto.newBuilder()
                                     .setName(input.getName())
                                     .setEmail(input.getEmail())
                                     .setImageUrl(input.getImage_url())
                                     .setPurchasedStat(input.getPurchased_stat().floatValue())
                                     .setMoneySavedStat(input.getMoney_saved_stat().floatValue())
                                     .setWasteSavedStat(input.getWaste_saved_stat().floatValue())
                                     .build());

        return toAccount(response.getAccount());
    }

    public Account updateAccount(UpdateAccountInput input) {
        AccountDto account = marketplaceServiceClient.getAccount(GetAccountRequest.newBuilder()
                                                                                  .setId(input.getId())
                                                                                  .build())
                                                     .getAccount();
        if (account == null) {
            throw new RuntimeException("Product not found");
        }
        UpdateAccountResponse response = marketplaceServiceClient
            .updateAccount(toUpdateAccount(input, account));

        return toAccount(response.getAccount());
    }

    public Ingredients getIngredients(GetIngredientsInput input) {
        GetIngredientsResponse ingredients = marketplaceServiceClient.getIngredients(GetIngredientsRequest.newBuilder()
                                                                                                          .setImage(input.getImage())
                                                                                                          .build());
        return Converters.toIngredients(ingredients);
    }

    public Product deleteProduct(DeleteProductInput input) {
        DeleteMarketplaceResponse response = marketplaceServiceClient.deleteMarketplace(DeleteMarketplaceRequest.newBuilder()
                                                                                                                .setId(input.getId())
                                                                                                                .build());
        return toProduct(response.getMarketplace());
    }
}
