package nalix.flowerfoods.core.domain.gateway.core;

import nalix.flowerfoods.marketplace.service.client.MarketplaceServiceClient;
import nalix.flowerfoods.supply.service.client.SupplyServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
@ComponentScan
public class CoreDomainGatewayCoreConfig {

    private final Environment env;

    @Autowired
    public CoreDomainGatewayCoreConfig(final Environment env) {
        this.env = env;
    }

    @Bean
    public MarketplaceServiceClient marketplaceServiceClient() {
        return MarketplaceServiceClient.of(
            env.getRequiredProperty("core.services.marketplace-service.host", String.class),
            env.getRequiredProperty("core.services.marketplace-service.port", Integer.class)
        );
    }

    @Bean
    public SupplyServiceClient supplyServiceClient() {
        return SupplyServiceClient.of(
            env.getRequiredProperty("core.services.supply-service.host", String.class),
            env.getRequiredProperty("core.services.supply-service.port", Integer.class)
        );
    }
}
