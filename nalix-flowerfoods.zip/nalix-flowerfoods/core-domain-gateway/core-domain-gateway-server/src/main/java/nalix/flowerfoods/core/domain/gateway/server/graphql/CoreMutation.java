package nalix.flowerfoods.core.domain.gateway.server.graphql;

import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsMutation;
import com.netflix.graphql.dgs.InputArgument;
import nalix.flowerfoods.core.domain.gateway.core.CoreDomainGatewayCore;
import nalix.flowerfoods.core.domain.gateway.graphql.types.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@DgsComponent
public class CoreMutation {
    private final Logger log = LoggerFactory.getLogger(getClass());

    private final CoreDomainGatewayCore domainGatewayCore;

    public CoreMutation(CoreDomainGatewayCore domainGatewayCore) {
        this.domainGatewayCore = domainGatewayCore;
    }

    @DgsMutation
    public Product createProduct(@InputArgument("input") ProductInput input) {
        log.info("createProduct input={}", input);
        return domainGatewayCore.createProduct(input);
    }

    @DgsMutation
    public Product updateProduct(@InputArgument("input") UpdateProductInput input) {
        log.info("updateProduct input={}", input);
        return domainGatewayCore.updateProduct(input);
    }

    @DgsMutation
    public Product deleteProduct(@InputArgument("input") DeleteProductInput input){
        log.info("deleteProduct input={}", input);
        return domainGatewayCore.deleteProduct(input);
    }

    @DgsMutation
    public Account createAccount(@InputArgument("input") AccountInput input) {
        log.info("createAccount input={}", input);
        return domainGatewayCore.createAccount(input);
    }

    @DgsMutation
    public Account updateAccount(@InputArgument("input") UpdateAccountInput input) {
        log.info("updateAccount input={}", input);
        return domainGatewayCore.updateAccount(input);
    }

    @DgsMutation
    public Supply createSupply(@InputArgument("input") SupplyInput input) {
        log.info("createSupply input={}", input);
        return domainGatewayCore.createSupply(input);
    }

    @DgsMutation
    public Supply updateSupply(@InputArgument("input") UpdateSupplyInput input) {
        log.info("updateSupply input={}", input);
        return domainGatewayCore.updateSupply(input);
    }
}
