package nalix.flowerfoods.core.domain.gateway.server.graphql;

import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsQuery;
import com.netflix.graphql.dgs.InputArgument;
import nalix.flowerfoods.core.domain.gateway.core.CoreDomainGatewayCore;
import nalix.flowerfoods.core.domain.gateway.graphql.types.*;

@DgsComponent
public class CoreFetcher {

    private final CoreDomainGatewayCore domainGatewayCore;

    public CoreFetcher(CoreDomainGatewayCore domainGatewayCore) {
        this.domainGatewayCore = domainGatewayCore;
    }

    @DgsQuery
    public Product product(@InputArgument("input") String input) {
        return domainGatewayCore.fetchProduct(input);
    }

    @DgsQuery
    public Product[] productList(@InputArgument ("input")ProductFilters productFilters
                                 ) {
        if(productFilters == null){
            return domainGatewayCore.fetchProducts("", "", 0.0F, 0.0F, "", "", "", 0, 0);
        } else {
            String tempName;
            String tempType;
            Float latitude;
            Float longitude;
            String tempIsAvailable;
            String tempSortBy;
            String tempSortDirection;
            int start_page;
            int page_size;

            if(productFilters.getName() == null){
                tempName = "";
            }else{
                tempName = productFilters.getName();
            }
            if(productFilters.getType() == null){
                tempType = "";
            }else{
                tempType = productFilters.getType();
            }
            if(productFilters.getAccount_latitude() == null){
                latitude = 0.0F;
            }else{
                latitude = productFilters.getAccount_latitude().floatValue();
            }
            if(productFilters.getAccount_longitude() == null){
                longitude = 0.0F;
            }else{
                longitude = productFilters.getAccount_longitude().floatValue();
            }
            if(productFilters.getIs_available() == null){
                tempIsAvailable = "";
            }else{
                tempIsAvailable = productFilters.getIs_available();
            }
            if(productFilters.getSort_by() == null){
                tempSortBy = "";
            }else{
               tempSortBy = productFilters.getSort_by();
            }
            if(productFilters.getSort_direction() == null){
                tempSortDirection = "";
            }else{
                tempSortDirection = productFilters.getSort_direction();
            }
            if(productFilters.getStart_page() == null){
                start_page = 0;
            }else{
                start_page = productFilters.getStart_page();
            }
            if(productFilters.getPage_size() == null){
                page_size = 0;
            }else{
                page_size = productFilters.getPage_size();
            }
            return domainGatewayCore.fetchProducts(tempName, tempType, latitude, longitude, tempIsAvailable, tempSortBy, tempSortDirection, start_page, page_size);
        }
    }

    @DgsQuery
    public Account account(@InputArgument("input") String input) {
        return domainGatewayCore.fetchAccount(input);
    }

    @DgsQuery
    public Account[] accountList() {
        return domainGatewayCore.fetchAccounts();
    }

    @DgsQuery
    public Supply supply(@InputArgument("input") String input) {
        return domainGatewayCore.fetchSupply(input);
    }

    @DgsQuery
    public Supply[] supplyList() {
        return domainGatewayCore.fetchSupplies();
    }

    @DgsQuery
    public Ingredients ingredientList (@InputArgument("input") GetIngredientsInput input){
        return domainGatewayCore.getIngredients(input);
    }
}
