package nalix.flowerfoods.core.domain.gateway.server;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.context.annotation.Import;
import nalix.flowerfoods.core.domain.gateway.core.CoreDomainGatewayCoreConfig;

@SpringBootApplication(exclude = {
        LiquibaseAutoConfiguration.class,
        DataSourceAutoConfiguration.class
})
@Import({
        CoreDomainGatewayCoreConfig.class,
})
public class CoreDomainGatewayServerConfig {

}
