# core-domain-gateway-bom

A [Bill of Materials](https://www.baeldung.com/spring-maven-bom) for the Core Domain Gateway.

## Use

To use any of the modules from this project, you should include it's Bill of Materials in the parent pom of your service:

```xml
    <properties>
        <nalix.flowerfoods.core-domain-gateway.version>VERSION</nalix.flowerfoods.core-domain-gateway.version>
    </properties>

    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>nalix.flowerfoods</groupId>
                <artifactId>core-domain-gateway-bom</artifactId>
                <version>${nalix.flowerfoods.core-domain-gateway.version.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    <dependencyManagement>
```