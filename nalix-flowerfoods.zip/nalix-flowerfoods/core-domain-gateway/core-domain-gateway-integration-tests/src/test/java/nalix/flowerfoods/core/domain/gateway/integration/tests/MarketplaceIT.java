package nalix.flowerfoods.core.domain.gateway.integration.tests;

import com.google.protobuf.StringValue;
import com.netflix.graphql.dgs.client.codegen.GraphQLQueryRequest;
import nalix.flowerfoods.core.domain.gateway.graphql.client.*;
import nalix.flowerfoods.core.domain.gateway.graphql.types.*;
import nalix.flowerfoods.marketplace.service.grpc.v1.AccountDto;
import nalix.flowerfoods.marketplace.service.grpc.v1.CreateAccountResponse;
import nalix.flowerfoods.marketplace.service.grpc.v1.CreateMarketplaceResponse;
import nalix.flowerfoods.marketplace.service.grpc.v1.MarketplaceDto;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static nalix.flowerfoods.marketplace.service.grpc.v1.MarketplaceServiceGrpc.getCreateAccountMethod;
import static nalix.flowerfoods.marketplace.service.grpc.v1.MarketplaceServiceGrpc.getCreateMarketplaceMethod;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.grpcmock.GrpcMock.stubFor;
import static org.grpcmock.GrpcMock.unaryMethod;

public class MarketplaceIT extends CoreDomainGatewayBaseIT {
//    private final Logger  log              = LoggerFactory.getLogger(getClass());
//    private       String  name             = "Brewers Yeast";
//    private       String  type             = "raw-material";
//    private       Integer   quantity         = 500;
//    private       String  quantityUnit     = "lb";
//    private       String  location         = "Modesto, CA";
//    private       Float   wasteProbability = 95.00F;
//    private       Float   price            = 350.00F;
//    private       Float   originalPrice    = 650.00F;
//    private       Boolean isAvailable      = true;
//
//    @Test
//    void test_createProductSuccess() {
//        stubCreateMarketplaceServiceCall();
//
//        ProductInput input = ProductInput.newBuilder()
//                                         .name(name)
//                                         .type(type)
//                                         .isAvailable(true)
//                                         .quantity(quantity)
//                                         .quantityUnit(quantityUnit)
//                                         .price(124.12)
//                                         .originalPrice(120.0)
//                                         .latitude(111.111)
//                                         .longitude(112.112)
//                                         .wasteProbability(0.2)
//                                         .location("USA")
//                                         .availableDate("12/12/2012")
//                                         .price_increase(30.0)
//                                         .rating(3.4)
//                                         .image_url("xyz.jpg")
//                                         .build();
//        CreateProductGraphQLQuery query = CreateProductGraphQLQuery.newRequest()
//                                                                   .input(input)
//                                                                   .build();
//        CreateProductProjectionRoot projection = new CreateProductProjectionRoot()
//            .id()
//            .name()
//            .type()
//            .isAvailable()
//            .quantity()
//            .quantityUnit()
//            .price()
//            .originalPrice()
//            .latitude()
//            .longitude()
//            .wasteProbability()
//            .location()
//            .availableDate()
//            .price_increase()
//            .rating()
//            .image_url();
//        GraphQLQueryRequest graphQLQueryRequest = new GraphQLQueryRequest(query, projection);
//        log.info(graphQLQueryRequest.serialize());
//
//        Product response = queryExecutor.executeAndExtractJsonPathAsObject(
//            graphQLQueryRequest.serialize(),
//            "data.createProduct",
//            Product.class);
//
//        assertThat(response).isNotNull();
//        assertThat(response.getId()).isEqualTo(uuid);
//        assertThat(response.getName()).isEqualTo(name);
//    }
//
//    @Test
//    void test_createAccountSuccess() {
//        stubCreateAccountServiceCall();
//
//        AccountInput input = AccountInput.newBuilder()
//                                         .name(name)
//                                         .email("account.com")
//                                         .image_url("image.com")
//                                         .purchased_stat(0.0)
//                                         .money_saved_stat(0.0)
//                                         .waste_saved_stat(0.0)
//                                         .build();
//        CreateAccountGraphQLQuery query = CreateAccountGraphQLQuery.newRequest()
//                                                                   .input(input)
//                                                                   .build();
//        CreateAccountProjectionRoot projection = new CreateAccountProjectionRoot()
//            .id()
//            .name()
//            .email()
//            .image_url()
//            .purchased_stat()
//            .money_saved_stat()
//            .waste_saved_stat();
//        GraphQLQueryRequest graphQLQueryRequest = new GraphQLQueryRequest(query, projection);
//        log.info(graphQLQueryRequest.serialize());
//
//        Product response = queryExecutor.executeAndExtractJsonPathAsObject(
//            graphQLQueryRequest.serialize(),
//            "data.createAccount",
//            Product.class);
//
//        assertThat(response).isNotNull();
//        assertThat(response.getId()).isEqualTo(uuid);
//        assertThat(response.getName()).isEqualTo(name);
//    }
//
//    private void stubCreateMarketplaceServiceCall() {
//        MarketplaceDto marketplace = MarketplaceDto.newBuilder()
//                                                   .setId(StringValue.of(uuid))
//                                                   .setName(name)
//                                                   .setType(type)
//                                                   .setIsAvailable(true)
//                                                   .setQuantity(quantity)
//                                                   .setQuantityUnit(quantityUnit)
//                                                   .setPrice(124.12F)
//                                                   .setOriginalPrice(120.0f)
//                                                   .setLatitude(111.111)
//                                                   .setLongitude(112.112)
//                                                   .setWasteProbability(0.2F)
//                                                   .setLocation("USA")
//                                                   .setAvailableDate("12/12/2012")
//                                                   .setPriceIncrease(30.0F)
//                                                   .setRating(3.4F)
//                                                   .setImageUrl("xyz.jpg")
//                                                   .build();
//        CreateMarketplaceResponse response = CreateMarketplaceResponse.newBuilder()
//                                                                      .setMarketplace(marketplace)
//                                                                      .build();
//
//        stubFor(unaryMethod(getCreateMarketplaceMethod()).willReturn(response));
//    }
//
//    private void stubCreateAccountServiceCall() {
//        AccountDto account = AccountDto.newBuilder()
//                                       .setId(StringValue.of(uuid))
//                                       .setName(name)
//                                       .setEmail("account.com")
//                                       .setImageUrl("image.com")
//                                       .setPurchasedStat(0.0F)
//                                       .setMoneySavedStat(0.0F)
//                                       .setWasteSavedStat(0.0F)
//                                       .build();
//        CreateAccountResponse response = CreateAccountResponse.newBuilder()
//                                                              .setAccount(account)
//                                                              .build();
//
//        stubFor(unaryMethod(getCreateAccountMethod()).willReturn(response));
//    }
}
