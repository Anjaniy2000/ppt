package nalix.flowerfoods.core.domain.gateway.integration.tests;

import com.google.protobuf.StringValue;
import com.netflix.graphql.dgs.client.codegen.GraphQLQueryRequest;
import nalix.flowerfoods.core.domain.gateway.graphql.client.CreateSupplyGraphQLQuery;
import nalix.flowerfoods.core.domain.gateway.graphql.client.CreateSupplyProjectionRoot;
import nalix.flowerfoods.core.domain.gateway.graphql.types.Supply;
import nalix.flowerfoods.core.domain.gateway.graphql.types.SupplyInput;
import nalix.flowerfoods.supply.service.grpc.v1.CreateSupplyResponse;
import nalix.flowerfoods.supply.service.grpc.v1.SupplyDto;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static nalix.flowerfoods.supply.service.grpc.v1.SupplyServiceGrpc.getCreateSupplyMethod;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.grpcmock.GrpcMock.stubFor;
import static org.grpcmock.GrpcMock.unaryMethod;

public class SupplyIT extends CoreDomainGatewayBaseIT {
    private final Logger log        = LoggerFactory.getLogger(getClass());
    private       String name       = "wheat";

    @Test
    void test_createSupplySuccess() {
        stubCreateSupplyServiceCall();

        SupplyInput input = SupplyInput.newBuilder()
                                       .name(name)
                                       .build();
        CreateSupplyGraphQLQuery query = CreateSupplyGraphQLQuery.newRequest()
                                                                 .input(input)
                                                                 .build();
        CreateSupplyProjectionRoot projection = new CreateSupplyProjectionRoot()
            .id()
            .name();
        GraphQLQueryRequest graphQLQueryRequest = new GraphQLQueryRequest(query, projection);
        log.info(graphQLQueryRequest.serialize());

        Supply response = queryExecutor.executeAndExtractJsonPathAsObject(
            graphQLQueryRequest.serialize(),
            "data.createSupply",
            Supply.class);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(uuid);
        assertThat(response.getName()).isEqualTo(name);
    }

    private void stubCreateSupplyServiceCall() {
        SupplyDto supply = SupplyDto.newBuilder()
                                    .setId(StringValue.of(uuid))
                                    .setName(name)
                                    .build();
        CreateSupplyResponse response = CreateSupplyResponse.newBuilder()
                                                            .setSupply(supply)
                                                            .build();

        stubFor(unaryMethod(getCreateSupplyMethod()).willReturn(response));
    }
}
