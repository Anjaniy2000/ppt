package nalix.flowerfoods.core.domain.gateway.integration.tests.config;

import org.grpcmock.GrpcMock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.netflix.graphql.dgs.DgsQueryExecutor;
import nalix.flowerfoods.core.domain.gateway.server.CoreDomainGatewayServer;

@Configuration
public class IntegrationTestsConfig {
    private final String grpcMockPort = Integer.toString(GrpcMock.getGlobalPort());


    @Bean(initMethod = "start", destroyMethod = "stop")
    public CoreDomainGatewayServer coreDomainGatewayServer() {
        return new CoreDomainGatewayServer()
            .withProperty("core.services.marketplace-service.host", "localhost")
            .withProperty("core.services.marketplace-service.port", grpcMockPort)
            .withProperty("core.services.supply-service.host", "localhost")
            .withProperty("core.services.supply-service.port", grpcMockPort)
            .withRandomPorts();
    }

    @Bean
    public DgsQueryExecutor queryExecutor(CoreDomainGatewayServer server) {
        return server.getContext()
                     .getBean(DgsQueryExecutor.class);
    }
}
