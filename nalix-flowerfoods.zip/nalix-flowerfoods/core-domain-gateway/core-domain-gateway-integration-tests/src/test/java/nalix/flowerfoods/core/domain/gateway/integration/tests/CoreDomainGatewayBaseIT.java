package nalix.flowerfoods.core.domain.gateway.integration.tests;

import com.netflix.graphql.dgs.DgsQueryExecutor;
import nalix.flowerfoods.marketplace.service.client.MarketplaceServiceClient;
import nalix.flowerfoods.marketplace.service.grpc.v1.MarketplaceServiceGrpc;
import nalix.flowerfoods.platform.test.GrpcMockClientConfigurer;
import nalix.flowerfoods.supply.service.client.SupplyServiceClient;
import nalix.flowerfoods.supply.service.grpc.v1.SupplyServiceGrpc;
import org.grpcmock.junit5.GrpcMockExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import nalix.flowerfoods.core.domain.gateway.integration.tests.config.IntegrationTestsConfig;
import nalix.flowerfoods.core.domain.gateway.server.CoreDomainGatewayServer;

import java.util.UUID;


@ExtendWith(value = {GrpcMockExtension.class, SpringExtension.class})
@ContextConfiguration(classes = {IntegrationTestsConfig.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class CoreDomainGatewayBaseIT {

    @Autowired
    private CoreDomainGatewayServer server;

    @Autowired
    protected DgsQueryExecutor queryExecutor;

    String uuid = UUID.randomUUID()
                      .toString();

    @BeforeEach
    public void setUpClients() {
        GrpcMockClientConfigurer.configure(server.getContext())
                                .client(MarketplaceServiceClient.class, MarketplaceServiceGrpc.class)
                                .client(SupplyServiceClient.class, SupplyServiceGrpc.class);
    }
}
