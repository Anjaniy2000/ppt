# Core Domain Gateway

**// TODO:** Add description of your project's business function.

Generated from the [Java Spring Boot GraphQL Domain Gateway Archetype](https://github.com/nax-platform/java-spring-boot-graphql-domain-gateway-archetype). 

## Build System
This project uses [Maven](https://maven.apache.org/) as its build system. Common goals include

| Goal    | Description                                                           |
|---------|-----------------------------------------------------------------------|
| clean   | Removes previously generated build files within `target` directories  |
| package | Builds and tests the project.                                         |
| install | Installs the project to your local repository for use as a dependency |

For information on Spring-specific tasks, see the [Spring Boot Maven Plugin](https://docs.spring.io/spring-boot/docs/current/maven-plugin/reference/htmlsingle/#?.?) docs.

This is a multi-module project. To run a goal in a particular module, use the `-f` flag. For example, we could clean and
regenerate the files from our protobuf definition like this:
```bash
$ mvn -f core-domain-gateway-graphql clean generate-sources
```

## Running the Server
This server accepts connections on the following ports:
- 9000: used for application GraphQL Service traffic.
- 9001: used to monitor the application over HTTP (see [Actuator endpoints](https://docs.spring.io/spring-boot/docs/current/reference/html/actuator.html#actuator.endpoints)).

Before starting the server, you must first create the application jars:
```bash
$ mvn install
```

Next, start the server locally or using Docker. You can verify things are up and running by looking at the [/health](http://localhost:9001/health) endpoint:
```bash
$ curl localhost:9001/health
```

### Local
From the project root, run
```bash
$ mvn -f core-domain-gateway-server spring-boot:run
```
To run the server in a non-blocking fashion, refer to the `spring-boot:start` and `spring-boot:stop` goals.

## Runtime Switches

The following are switches/settings that can be turned on or off when starting the server to affect how it operates. These
switches are use primarily as a developer convenience.

| System Property      | Environment Variable | Function                                                                  |
|:---------------------|----------------------|:--------------------------------------------------------------------------|
| -Dlogging-structured |                      | Turns on structured (JSON) logging, and turns off the Spring Boot banner. |
| -Dlogging-pretty     |                      | Turn on pretty printing when using structured-logging.                    |

## Modules

| Directory | Description |
| --------- | ----------- |
| [core-domain-gateway-bom](core-domain-gateway-bom/README.md) | Core Domain Gateway Bill of Materials. |
| [core-domain-gateway-core](core-domain-gateway-core/README.md) | Business Logic. Abstracts Persistence, defines Transaction Boundaries. Implements the API. |
| [core-domain-gateway-graphql](core-domain-gateway-graphql/README.md) | GraphQL spec. |
| [core-domain-gateway-integration-tests](core-domain-gateway-integration-tests/README.md) | Leverages the Client to test the Server and it's dependencies. |
| [core-domain-gateway-server](core-domain-gateway-server/README.md) | Transport/Protocol Host.  Wraps Core. |

## Key Dependencies

| Name                                                                                           | Scope                  | Description                                                            |
|------------------------------------------------------------------------------------------------|------------------------|------------------------------------------------------------------------|
| [GraphQL Spring Boot Starter](https://github.com/LogNet/grpc-spring-boot-starter)              | API/Remoting           | Auto-configures an embedded GraphQL server integrated with Spring Boot |
| [Spring Data JPA](https://docs.spring.io/spring-data/jpa/docs/2.5.1/reference/html/#reference) | Persistence            | ORM.                                                                   | 
| [k6](https://k6.io/)                                                                           | Load Tests             | JavaScript-driven load testing                                         |
| [AssertJ](https://joel-costigliola.github.io/assertj/)                                         | Unit Tests             | Fluent test assertions.                                                |
| [Mockito](https://site.mockito.org/)                                                           | Unit Tests             | Provides mocking and spying functionality.                             |
| [TestContainers](https://www.testcontainers.org/)                                              | Unit Tests, Containers | Programmatic container management.                                     |

## Contributions
**// TODO:** Add description of how you would like issues to be reported and people to reach out.