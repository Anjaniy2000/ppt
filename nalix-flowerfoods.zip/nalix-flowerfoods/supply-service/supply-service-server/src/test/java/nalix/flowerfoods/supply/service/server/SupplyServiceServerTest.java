package nalix.flowerfoods.supply.service.server;

import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.*;

public class SupplyServiceServerTest {

}