package nalix.flowerfoods.supply.service.server.grpc;

import io.grpc.stub.StreamObserver;
import org.lognet.springboot.grpc.GRpcService;
import nalix.flowerfoods.supply.service.core.SupplyServiceCore;
import nalix.flowerfoods.supply.service.grpc.v1.*;
import nalix.flowerfoods.supply.service.grpc.v1.SupplyServiceGrpc.SupplyServiceImplBase;

@GRpcService
public class SupplyServiceGrpcImpl extends SupplyServiceImplBase {

    private final SupplyServiceCore service;

    public SupplyServiceGrpcImpl(SupplyServiceCore service) {
        this.service = service;
    }

    @Override
    public void createSupply(SupplyDto request, StreamObserver<CreateSupplyResponse> responseObserver) {
        CreateSupplyResponse supplyResponse = service.createSupply(request);
        responseObserver.onNext(supplyResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void getSupply(GetSupplyRequest request, StreamObserver<GetSupplyResponse> responseObserver) {
        GetSupplyResponse response = service.getSupply(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getSupplies(GetSuppliesRequest request, StreamObserver<GetSuppliesResponse> responseObserver) {
        GetSuppliesResponse response = service.getSupplies(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void updateSupply(SupplyDto request, StreamObserver<UpdateSupplyResponse> responseObserver) {
        UpdateSupplyResponse response = service.updateSupply(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}