package nalix.flowerfoods.supply.service.server;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.context.annotation.Import;
import nalix.flowerfoods.supply.service.core.SupplyServiceCoreConfig;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(
        exclude = {LiquibaseAutoConfiguration.class, DataSourceAutoConfiguration.class}
)
@Import({
        SupplyServiceCoreConfig.class,
})
public class SupplyServiceServerConfig {

}
