package nalix.flowerfoods.supply.service.integration.tests;

import org.junit.jupiter.api.Test;
import nalix.flowerfoods.supply.service.grpc.v1.*;
import nalix.flowerfoods.supply.service.persistence.repositories.SupplyRepository;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

class SupplyServiceGrpcTest extends SupplyServiceBaseIT {

    @Test
    void test_createSupply() {
        CreateSupplyResponse response = client.createSupply(SupplyDto.newBuilder().setName("Supply").build());
    }

    @Test
    void test_getCreateAndGetSupply() {
        CreateSupplyResponse createResponse = client.createSupply(SupplyDto.newBuilder().setName("Supply").build());

        GetSupplyResponse getResponse = client.getSupply(
                GetSupplyRequest.newBuilder().setId(createResponse.getSupply().getId().getValue()).build()
        );

        assertThat(createResponse.getSupply()).isEqualTo(getResponse.getSupply());
    }

    @Test
    void testGetSupplies() {
        long existingRecords = server.getContext().getBean(SupplyRepository.class).count();

        int pageSize = 10;
        int recordsToAdd = 20;
        for (int i = 0; i < recordsToAdd; i++) {
            client.createSupply(SupplyDto.newBuilder().setName("Supply " + i).build());
        }

        GetSuppliesResponse firstPageResponse = client.getSupplies(GetSuppliesRequest.newBuilder()
                .setPageSize(pageSize)
                .setStartPage(0)
                .build()
        );

        assertThat(firstPageResponse.getTotalElements()).isEqualTo(existingRecords + recordsToAdd);
        assertThat(firstPageResponse.getHasNext()).isTrue();
        assertThat(firstPageResponse.getHasPrevious()).isFalse();

        GetSuppliesResponse lastPageResponse = client.getSupplies(GetSuppliesRequest.newBuilder()
                .setPageSize(pageSize)
                .setStartPage(firstPageResponse.getTotalPages() - 1)
                .build()
        );

        assertThat(lastPageResponse.getHasNext()).isFalse();
        assertThat(lastPageResponse.getHasPrevious()).isTrue();
    }
}
