package nalix.flowerfoods.supply.service.integration.tests;


import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import nalix.flowerfoods.supply.service.client.SupplyServiceClient;
import nalix.flowerfoods.supply.service.integration.tests.config.IntegrationTestsConfig;
import nalix.flowerfoods.supply.service.server.SupplyServiceServer;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = { IntegrationTestsConfig.class })
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class SupplyServiceBaseIT {
    @Autowired
    protected SupplyServiceServer server;

    @Autowired
    protected SupplyServiceClient client;
}