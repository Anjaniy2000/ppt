package nalix.flowerfoods.supply.service.integration.tests.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import nalix.flowerfoods.supply.service.client.SupplyServiceClient;
import nalix.flowerfoods.supply.service.server.SupplyServiceServer;


@Configuration
public class IntegrationTestsConfig {
    

    @Bean(initMethod = "start", destroyMethod = "stop")
    public SupplyServiceServer supplyServiceServer() {
         return new SupplyServiceServer()
                .withRandomPorts()
                .withTempDb();
    }

    @Bean
    public SupplyServiceClient supplyServiceClient(SupplyServiceServer server) {
        return SupplyServiceClient.of("localhost", server.getGrpcPort());
    }
}
