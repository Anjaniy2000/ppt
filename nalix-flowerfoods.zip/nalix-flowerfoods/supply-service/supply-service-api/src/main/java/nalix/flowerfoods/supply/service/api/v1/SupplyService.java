package nalix.flowerfoods.supply.service.api.v1;

import nalix.flowerfoods.supply.service.grpc.v1.*;

import java.util.Iterator;

public interface SupplyService {
    CreateSupplyResponse createSupply(SupplyDto supply);
    GetSuppliesResponse getSupplies(GetSuppliesRequest request);
    GetSupplyResponse getSupply(GetSupplyRequest request);
    UpdateSupplyResponse updateSupply(SupplyDto supply);
}
