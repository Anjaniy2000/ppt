package nalix.flowerfoods.supply.service.core.support;

import com.google.protobuf.StringValue;
import nalix.flowerfoods.supply.service.grpc.v1.SupplyDto;
import nalix.flowerfoods.supply.service.persistence.entities.SupplyEntity;
import java.util.UUID;

public class Converters {

    public static SupplyDto convert(SupplyEntity supplyEntity) {
        SupplyDto.Builder builder = SupplyDto.newBuilder()
                .setName(supplyEntity.getName());
        if (supplyEntity.getId() != null) {
            builder.setId(StringValue.of(supplyEntity.getId().toString()));
        }
        return builder.build();
    }

    public static SupplyEntity convert(SupplyDto supply) {
        SupplyEntity entity;
        if (supply.hasId()) {
            entity = new SupplyEntity(UUID.fromString(supply.getId().getValue()), supply.getName());
        } else {
            entity = new SupplyEntity(supply.getName());
        }
        return entity;
    }
}
