package nalix.flowerfoods.supply.service.core;
import nalix.flowerfoods.supply.service.persistence.SupplyServicePersistenceConfig;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({
        SupplyServicePersistenceConfig.class,
})
@ComponentScan
public class SupplyServiceCoreConfig {

}