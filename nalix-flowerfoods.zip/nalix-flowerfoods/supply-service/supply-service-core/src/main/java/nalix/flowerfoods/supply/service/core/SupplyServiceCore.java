package nalix.flowerfoods.supply.service.core;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import nalix.flowerfoods.supply.service.api.v1.SupplyService;
import nalix.flowerfoods.supply.service.core.support.Converters;
import nalix.flowerfoods.supply.service.grpc.v1.*;
import nalix.flowerfoods.supply.service.persistence.entities.SupplyEntity;
import nalix.flowerfoods.supply.service.persistence.repositories.SupplyRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import static nalix.flowerfoods.supply.service.core.support.Converters.convert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class SupplyServiceCore implements SupplyService {
    private final SupplyRepository repository;
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public SupplyServiceCore(
            SupplyRepository repository
        ) {
            this.repository = repository;
    }

    @Override
    public CreateSupplyResponse createSupply(SupplyDto supply) {
        SupplyEntity savedEntity = repository.save(new SupplyEntity(supply.getName()));
        return CreateSupplyResponse.newBuilder()
                .setSupply(convert(savedEntity))
                .build();
    }

    @Override
    public GetSuppliesResponse getSupplies(GetSuppliesRequest request) {
        int pageSize = Math.min(Math.max(request.getPageSize(), 10), 100);
        Pageable pageable = PageRequest.of(request.getStartPage(), pageSize);
        Page<SupplyEntity> page = repository.findAll(pageable);
        List<SupplyDto> supplies = page.stream().map(Converters::convert).collect(Collectors.toList());
        return GetSuppliesResponse.newBuilder()
                .addAllSupply(supplies)
                .setHasNext(page.hasNext())
                .setHasPrevious(page.hasPrevious())
                .setNextPage(page.getPageable().next().getPageNumber())
                .setTotalElements(page.getTotalElements())
                .setTotalPages(page.getTotalPages())
                .build();
    }

    @Override
    public GetSupplyResponse getSupply(GetSupplyRequest request) {
        Optional<SupplyEntity> response = repository.findById(UUID.fromString(request.getId()));
        if (response.isPresent()) {
            SupplyEntity entity = response.get();
            return GetSupplyResponse.newBuilder().setSupply(convert(entity)).build();
        }
        return null; // TODO: Handle error!
    }

    @Override
    public UpdateSupplyResponse updateSupply(SupplyDto supply) {
        if (supply.hasId()) {
            UUID id = UUID.fromString(supply.getId().getValue());
            Optional<SupplyEntity> entity = repository.findById(id);
            if (entity.isPresent()) {
                SupplyEntity supplyEntity = entity.get();
                supplyEntity.setName(supply.getName());
                repository.save(supplyEntity);
                return UpdateSupplyResponse.newBuilder().setSupply(convert(supplyEntity)).build();
            }
        }
        return UpdateSupplyResponse.getDefaultInstance();
    }
}
