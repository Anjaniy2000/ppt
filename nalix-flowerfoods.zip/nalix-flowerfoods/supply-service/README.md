# Supply Service

**// TODO:** Add description of your project's business function.

Generated from the [Java Spring Boot gRPC Service Archetype](https://github.com/nax-platform/java-spring-boot-grpc-service-archetype). 

[[_TOC_]]

## Prereqs
Running this service requires JDK 11+ and Maven to be configured with an Artifactory encrypted key.
Be sure to have [annotation processors](https://immutables.github.io/apt.html) enabled in your IDE. For development, be
sure to have Docker installed and running locally.

## Overview


## Build System
This project uses [Maven](https://maven.apache.org/) as its build system. Common goals include

| Goal    | Description                                                           |
|---------|-----------------------------------------------------------------------|
| clean   | Removes previously generated build files within `target` directories  |
| package | Builds and tests the project.                                         |
| install | Installs the project to your local repository for use as a dependency |

For information on Spring-specific tasks, see the [Spring Boot Maven Plugin](https://docs.spring.io/spring-boot/docs/current/maven-plugin/reference/htmlsingle/#?.?) docs.

This is a multi-module project. To run a goal in a particular module, use the `-f` flag. For example, we could clean and
regenerate the files from our protobuf definition like this:
```bash
$ mvn -f supply-service-grpc clean generate-sources
```

## Running the Server
This server accepts connections on the following ports:
- 9010: used for application gRPC Service traffic.
- 9011: used to monitor the application over HTTP (see [Actuator endpoints](https://docs.spring.io/spring-boot/docs/current/reference/html/actuator.html#actuator.endpoints)).
- 9012: exposes the ephemeral database port
- 9019: remote debugging port

Before starting the server, you must first create the application jars:
```bash
$ mvn install
```

Next, start the server locally or using Docker. You can verify things are up and running by looking at the [/health](http://localhost:9011/health) endpoint:
```bash
$ curl localhost:9011/health
```
You can try to create an entity using a gRPC client, like [grpcurl](https://github.com/fullstorydev/grpcurl) (CLI) or [grpcui](https://github.com/fullstorydev/grpcui) (GUI).
For example,
```bash
$ grpcurl -plaintext -d '{"name": "test"}' localhost:9010 \
    nalix.flowerfoods.supply.service.grpc.v1.SupplyService/CreateSupply
```

### Local
From the project root, install then run the server:
```bash
$ mvn clean install
$ mvn -f supply-service-server spring-boot:run -Dspring-boot.run.jvmArguments="-Dtemp-db -Dlocalstack"
```
To run the server in a non-blocking fashion, refer to the `spring-boot:start` and `spring-boot:stop` goals. More information
about the available JVM arguments can be found in the [Runtime Switches](#runtime-switches) section.

## Runtime Switches

The following are switches/settings that can be turned on or off when starting the server to affect how it operates. These
switches are use primarily as a developer convenience.

| System Property | Environment Variable | Function |
|:---|---|:---|
| -Dtemp-db |   | Starts the server with a dynamically generated Postgres DB in a Docker container on a randomized port. The JDBC URL for the database is written to the logs, and can be copy/pasted into your database IDE. The username/password is postgres/password. |
| -Dlogging-structured |   | Turns on structured (JSON) logging, and turns off the Spring Boot banner. |
| -Dlogging-pretty |   | Turn on pretty printing when using structured-logging. |
| -Dlog-sql |   | Turns on SQL logging. |
| -Dlocalstack |   | Spins up AWS resources (ex. SQS) along side the server using [LocalStack](https://github.com/localstack/localstack) and Docker.|

## Modules

| Directory | Description |
| --------- | ----------- |
| [supply-service-api](supply-service-api/README.md) | Service Interfaces with a gRPC model. |
| [supply-service-bom](supply-service-bom/README.md) | Supply Service Bill of Materials. |
| [supply-service-client](supply-service-client/README.md) | gRPC Client. Implements the API. |
| [supply-service-core](supply-service-core/README.md) | Business Logic. Abstracts Persistence, defines Transaction Boundaries. Implements the API. |
| [supply-service-grpc](supply-service-grpc/README.md) | gRPC/Protobuf spec. |
| [supply-service-integration-tests](supply-service-integration-tests/README.md) | Leverages the Client to test the Server and it's dependencies. |
| [supply-service-persistence](supply-service-persistence/README.md) | Persistence Entities and Data Repositories. Wrapped by Core. | 
| [supply-service-server](supply-service-server/README.md) | Transport/Protocol Host.  Wraps Core. |

## Key Dependencies

| Name                                                                                           | Scope                                           | Description                                                         |
|------------------------------------------------------------------------------------------------|-------------------------------------------------|---------------------------------------------------------------------|
| [gRPC Spring Boot Starter](https://github.com/LogNet/grpc-spring-boot-starter)                 | API/Remoting                                    | Auto-configures an embedded gRPC server integrated with Spring Boot |
| [Spring Data JPA](https://docs.spring.io/spring-data/jpa/docs/2.5.1/reference/html/#reference) | Persistence                                     | ORM.                                                                | 
| [AssertJ](https://joel-costigliola.github.io/assertj/)                                         | Unit Tests                                      | Fluent test assertions.                                             |
| [Mockito](https://site.mockito.org/)                                                           | Unit Tests                                      | Provides mocking and spying functionality.                          |
| [TestContainers](https://www.testcontainers.org/)                                              | Unit Tests, Containers                          | Programmatic container management.                                  |
| [LocalStack](https://github.com/localstack/localstack)                                         | Provides Docker images for common AWS services. |                                                                     |

## Contributions
**// TODO:** Add description of how you would like issues to be reported and people to reach out.
