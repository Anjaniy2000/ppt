package nalix.flowerfoods.supply.service.client;

import io.grpc.ManagedChannelBuilder;
import nalix.flowerfoods.supply.service.api.v1.SupplyService;
import nalix.flowerfoods.supply.service.grpc.v1.*;

public class SupplyServiceClient implements SupplyService {
    SupplyServiceGrpc.SupplyServiceBlockingStub stub;

    public static SupplyServiceClient of(String host, int port) {
        return new SupplyServiceClient(ManagedChannelBuilder.forAddress(host, port).usePlaintext());
    }

    private SupplyServiceClient(ManagedChannelBuilder<?> channelBuilder) {
        this.stub = SupplyServiceGrpc.newBlockingStub(channelBuilder.build());
    }

    @Override
    public CreateSupplyResponse createSupply(SupplyDto supply) {
        return stub.createSupply(supply);
    }

    @Override
    public GetSuppliesResponse getSupplies(GetSuppliesRequest request) {
        return stub.getSupplies(request);
    }

    @Override
    public GetSupplyResponse getSupply(GetSupplyRequest request) {
        return stub.getSupply(request);
    }

    @Override
    public UpdateSupplyResponse updateSupply(SupplyDto supply) {
        return stub.updateSupply(supply);
    }
}
