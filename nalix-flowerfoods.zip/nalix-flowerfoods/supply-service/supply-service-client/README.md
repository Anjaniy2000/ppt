# supply-service-client

## Dependency

```xml
    <dependency>
        <groupId>nalix.flowerfoods</groupId>
        <artifactId>supply-service-client</artifactId>
    </dependency>
```