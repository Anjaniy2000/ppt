package nalix.flowerfoods.supply.service.persistence.repositories;

import com.querydsl.core.types.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import nalix.flowerfoods.supply.service.persistence.entities.SupplyEntity;
import nalix.flowerfoods.supply.service.persistence.entities.QSupplyEntity;

public class SupplyRepositoryImpl implements SupplyRepositoryExtensions {

    @Autowired
    SupplyRepository supplyRepository;

    @Override
    public Page<SupplyEntity> findByNameQueryDsl(String name, Pageable pageable) {
        QSupplyEntity qm = QSupplyEntity.supplyEntity;
        Predicate predicate = qm.name.eq(name);
        return supplyRepository.findAll(predicate, pageable);
    }
}
