package nalix.flowerfoods.supply.service.persistence.entities;

import nalix.flowerfoods.platform.persistence.jpa.AbstractEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@Entity
@Table(name = "supply")
public class SupplyEntity extends AbstractEntity {

    @Column(name = "name")
    private String name;

    // Hibernate requires a default constructor
    public SupplyEntity() {}

    public SupplyEntity(@NotNull String name) {
        this.name = name;
    }

    public SupplyEntity(@NotNull UUID id, @NotNull String name) {
        setId(id);
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(@NotNull String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "SupplyEntity{" +
            "id='" + getId() + '\'' +
            "name='" + name + '\'' +
            '}';
    }
}