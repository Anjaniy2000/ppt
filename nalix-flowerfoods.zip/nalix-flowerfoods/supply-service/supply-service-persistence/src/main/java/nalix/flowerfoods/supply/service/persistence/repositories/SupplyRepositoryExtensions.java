package nalix.flowerfoods.supply.service.persistence.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import nalix.flowerfoods.supply.service.persistence.entities.SupplyEntity;

/**
 * Extensions to the {@link SupplyRepository}.  This allows for concrete implementation in the
 * {@link SupplyRepositoryImpl} using QueryDSL or with a native EntityManager.
 */
public interface SupplyRepositoryExtensions {

    Page<SupplyEntity> findByNameQueryDsl(String name, Pageable pageable);
}
