package nalix.flowerfoods.supply.service.persistence.repositories;

import nalix.flowerfoods.supply.service.persistence.entities.SupplyEntity;
import nalix.flowerfoods.supply.service.persistence.repositories.SupplyRepositoryExtensions;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.UUID;

/**
 * @author Archetect
 */
@Repository
public interface SupplyRepository extends
    JpaRepository<SupplyEntity, UUID>,
    QuerydslPredicateExecutor<SupplyEntity>,
    SupplyRepositoryExtensions
{

}