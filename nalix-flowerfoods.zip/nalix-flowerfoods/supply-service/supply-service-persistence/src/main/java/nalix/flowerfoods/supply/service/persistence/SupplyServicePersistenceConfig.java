package nalix.flowerfoods.supply.service.persistence;

import com.zaxxer.hikari.HikariDataSource;
import liquibase.integration.spring.SpringLiquibase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.testcontainers.containers.CockroachContainer;
import org.testcontainers.containers.JdbcDatabaseContainer;
import org.testcontainers.utility.DockerImageName;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Optional;

/**
 * @author Archetect
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {
                "nalix.flowerfoods.supply.service.persistence.repositories",
        },
        entityManagerFactoryRef = "supplyEMF",
        transactionManagerRef = "supplyTM")
@ComponentScan
public class SupplyServicePersistenceConfig {
    private static final Logger logger = LoggerFactory.getLogger(SupplyServicePersistenceConfig.class );
    private final Environment env;
    private static final String COCKROACH_DB_IMAGE = "cockroachdb/cockroach:v22.1.0";

    @Autowired
    public SupplyServicePersistenceConfig(final Environment env) {
        this.env = env;
    }

    @Bean(name = "supplyTM")
    @Qualifier("supply")
    public JpaTransactionManager supplyTM(
    @Qualifier("supplyDS") final DataSource dataSource,
    @Qualifier("supplyEMF") final EntityManagerFactory emf) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setDataSource(dataSource);
        transactionManager.setEntityManagerFactory(emf);
        return transactionManager;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean supplyEMF(
    @Qualifier("supplyDS") final DataSource dataSource,
    @Qualifier("supplyVA") final JpaVendorAdapter vendorAdapter) {
        LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
        factory.setDataSource(dataSource);
        factory.setJpaVendorAdapter(vendorAdapter);
        factory.setPersistenceUnitName("supply");
        factory.setPackagesToScan(
            "nalix.flowerfoods.supply.service.persistence.entities"
        );
        return factory;
    }

    @Bean
    @Qualifier("supply")
    public JdbcTemplate supplyJdbcTemplate(@Qualifier("supplyDS") final DataSource dataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.setDataSource(dataSource);
        return jdbcTemplate;
    }

    @Bean
    @ConditionalOnProperty(name = "liquibase", havingValue = "true", matchIfMissing = true)
    public SpringLiquibase supplyLiquibase(@Qualifier("supplyDS") final DataSource dataSource) {
        logger.info("Applying Liquibase");
        SpringLiquibase liquibase = new SpringLiquibase();
//         liquibase.setContexts(RuntimeMode.current().name());
        liquibase.setDataSource(dataSource);
        if (env.containsProperty("initdb") || env.containsProperty("gateway.initdb")) {
            liquibase.setDropFirst(true);
        }
        liquibase.setChangeLog("classpath:db/supply-service/changelog-master.xml");
        return liquibase;
    }

    @Bean(initMethod = "start", destroyMethod = "stop")
    @ConditionalOnProperty(name = "temp-db")
    public JdbcDatabaseContainer<?>  databaseContainer() {
        return new CockroachContainer(DockerImageName.parse(COCKROACH_DB_IMAGE));
    }

    @Bean
    public DataSource supplyDS(Optional<JdbcDatabaseContainer<?>> databaseContainer) {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setPoolName("supply");
        logger.info("Configuring Supply Service DataSource");
        if (databaseContainer.isPresent()) {
            logger.info("Supply Service JDBC URL: {}", databaseContainer.get().getJdbcUrl());
            dataSource.setJdbcUrl(databaseContainer.get().getJdbcUrl());
            dataSource.setUsername(databaseContainer.get().getUsername());
            dataSource.setPassword(databaseContainer.get().getPassword());
        } else {
            dataSource.setJdbcUrl(env.getRequiredProperty("persistence.database.url"));
            dataSource.setUsername(env.getRequiredProperty("persistence.database.username"));
            dataSource.setPassword(env.getRequiredProperty("persistence.database.password"));
        }
        if (env.containsProperty("persistence.pool.maximumPoolSize")) {
            dataSource.setMaximumPoolSize(env.getProperty("persistence.pool.maximumPoolSize", Integer.class));
        }
        if (env.containsProperty("persistence.pool.connectionTimeout")) {
            dataSource.setConnectionTimeout(env.getProperty("persistence.pool.connectionTimeout", Long.class));
        }
        if (env.containsProperty("persistence.pool.maxLifetime")) {
            dataSource.setMaxLifetime(env.getProperty("persistence.pool.maxLifetime", Long.class));
        }
        if (env.containsProperty("persistence.pool.idleTimeout")) {
            dataSource.setIdleTimeout(env.getProperty("persistence.pool.idleTimeout", Long.class));
        }
        return dataSource;
    }

    @Bean
    public HibernateJpaVendorAdapter supplyVA() {
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setDatabase(Database.POSTGRESQL);
//         vendorAdapter.setShowSql(Switches.showSql.isEnabled());
        return vendorAdapter;
    }
}