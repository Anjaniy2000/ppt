package nalix.flowerfoods.platform.auth;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.common.base.Strings;
import nalix.flowerfoods.platform.errorhandling.exceptions.TokenValidationException;
import nalix.flowerfoods.platform.v1.types.IdentityProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class JWTService {

    private static final Logger logger = LoggerFactory.getLogger(JWTService.class);

    // TODO Update METADATA and ROLES urls to match service urls
    public static final String METADATA = "https://app.example.com/metadata";
    public static final String ROLES = "https://app.example.com/roles";

    public static final String USER_UUID = "user_uuid";
    public static final String ISS = "iss";
    public static final String SUB = "sub";

    public Optional<JWTUser> currentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof JWTUser) {
            return Optional.of((JWTUser) authentication.getPrincipal());
        } else {
            return Optional.empty();
        }
    }

    public JWTUser decodeJWTUser(String token) {
        Optional<DecodedJWT> optionalDecodedJWT = decodeJwt(token);

        if (optionalDecodedJWT.isEmpty()) {
            logger.warn("Token is not generated.");
            return null;
        }
        DecodedJWT decodedJWT = optionalDecodedJWT.get();

        //We have to catch this exception and return null for correct showing message in DGW response
        try {
            validateToken(decodedJWT);
        } catch (TokenValidationException e) {
            return null;
        }

        String userUuid = decodedJWT.getClaim(METADATA).asMap().get(USER_UUID).toString();
        List<SimpleGrantedAuthority> userRoles = decodedJWT.getClaim(ROLES).asList(String.class).stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                .toList();
        Claim issuerClaim = decodedJWT.getClaim(ISS);
        IdentityProvider identityProvider = IdentityProviderResolver.resolveIdentityProvider(issuerClaim.asString());
        Claim identityProviderId = decodedJWT.getClaim(SUB);
        if (identityProviderId.asString() != null) {
            return new JWTUser(
                    UUID.fromString(userUuid),
                    identityProvider,
                    identityProviderId.asString(),
                    token,
                    userRoles
            );
        }
        return null;
    }


    private Optional<DecodedJWT> decodeJwt(String token) {
        try {
            return Optional.of(JWT.decode(token));
        } catch (JWTDecodeException ex) {
            logger.warn("Error decoding JWT token.", ex);
            return Optional.empty();
        }
    }

    //We are validating here, that token contains two our custom fields METADATA (and checking) and ROLES.
    //If token doesn't contain one or more of these fields, we throw TokenValidationException.
    //If new required custom field appears, we also should validate it here.
    private void validateToken(DecodedJWT decodedJWT) {
        if (decodedJWT.getClaim(METADATA).isMissing()) {
            logger.warn("METADATA field is missing.");
            throw new TokenValidationException();
        }

        Object userUuid = decodedJWT.getClaim(METADATA).asMap().get(USER_UUID);
        if (userUuid == null || Strings.isNullOrEmpty(userUuid.toString())) {
            logger.warn("user_uuid field is missing");
            throw new TokenValidationException();
        }

        if (decodedJWT.getClaim(ROLES).isMissing() || decodedJWT.getClaim(ROLES).asList(String.class) == null) {
            logger.warn("ROLES field is missing");
            throw new TokenValidationException();
        }
    }

}
