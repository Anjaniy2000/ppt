package nalix.flowerfoods.platform.auth;

import nalix.flowerfoods.platform.v1.types.IdentityProvider;

public class IdentityProviderResolver {

    static IdentityProvider resolveIdentityProvider(String issuer) {
        if (issuer.toLowerCase().contains("auth0")) {
            return IdentityProvider.AUTH0;
        } else {
            return null;
        }
    }
}
