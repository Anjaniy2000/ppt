package nalix.flowerfoods.platform.auth.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import nalix.flowerfoods.platform.v1.types.IdentityProvider;
import org.springframework.security.test.context.support.WithSecurityContext;
import nalix.flowerfoods.platform.auth.testutils.WithJWTUserSecurityContextFactory;

@Retention(RetentionPolicy.RUNTIME)
@WithSecurityContext(factory = WithJWTUserSecurityContextFactory.class)
public @interface WithJWTUser {
  String userId() default "";

  IdentityProvider identityProvider() default IdentityProvider.AUTH0;

  String identityProviderId() default "";

  String role() default "";
}
