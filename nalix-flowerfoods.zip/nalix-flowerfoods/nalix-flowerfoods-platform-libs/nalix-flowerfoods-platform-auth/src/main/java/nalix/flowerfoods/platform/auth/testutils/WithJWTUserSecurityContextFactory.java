package nalix.flowerfoods.platform.auth.testutils;

import java.util.List;
import java.util.UUID;

import nalix.flowerfoods.platform.v1.types.IdentityProvider;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.test.context.support.WithSecurityContextFactory;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import nalix.flowerfoods.platform.auth.JWTUser;
import nalix.flowerfoods.platform.auth.annotations.WithJWTUser;

public class WithJWTUserSecurityContextFactory implements WithSecurityContextFactory<WithJWTUser> {

  public static final String DEFAULT_ROLE = "ROLE_BORROWER";

  @Override
  public SecurityContext createSecurityContext(WithJWTUser withJWTUser) {
    // Create empty context
    SecurityContext context = SecurityContextHolder.createEmptyContext();

    // Create the jwtUser from WithJWTUser annotation
    var userId =
            StringUtils.isEmpty(withJWTUser.userId()) ? UUID.randomUUID() : UUID.fromString(withJWTUser.userId());
    var identityProvider =
            withJWTUser.identityProvider().equals(IdentityProvider.UNSPECIFIED)
            || withJWTUser.identityProvider().equals(IdentityProvider.UNRECOGNIZED) ? IdentityProvider.AUTH0
                    : withJWTUser.identityProvider();
    var identityProviderId =
            StringUtils.isEmpty(withJWTUser.identityProviderId()) ? "auth0|000000000000000000000000" : withJWTUser.identityProviderId();
    var jwtToken = JWTTokenUtil.generateJwtToken(userId);
    var role = StringUtils.isEmpty(withJWTUser.role()) ? DEFAULT_ROLE : withJWTUser.role();
    JWTUser jwtUser = new JWTUser(userId, identityProvider, identityProviderId, jwtToken, List.of(new SimpleGrantedAuthority(role)));

    // Create Authentication Object
    Authentication auth = new PreAuthenticatedAuthenticationToken(jwtUser, jwtUser.getToken(), List.of(new SimpleGrantedAuthority(role)));
    auth.setAuthenticated(true);
    // Set the Auth to the context
    context.setAuthentication(auth);

    return context;
  }
}
