package nalix.flowerfoods.platform.auth;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.common.base.Strings;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import nalix.flowerfoods.platform.auth.testutils.JWTTokenUtil;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.security.PrivateKey;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;

class JWTServiceTest {

    // TODO update these fields to match 'JWTService'
    private static final String METADATA = "https://app.example.com/metadata";
    private static final String ROLES = "https://app.example.com/roles";

    private static JWTService JWTService;
    private static final String USER_ID_STR = "11111111-1111-1111-1111-111111111111";
    private static final String USER_UUID = "user_uuid";
    private static final String METADATA_USER_UUID = "user_uuid";
    private static final PrivateKey privateKey = JWTTokenUtil.getPrivateKey();

    @BeforeAll
    static void beforeTest() {
        JWTService = new JWTService();
    }

    /*
     * Here is a code snippet for generating a new JWT token which will be needed after updating
     * the METADATA and ROLES urls. You can check the decoded token content with 'jwt.io'.
     *
     *   String token = JWTTokenUtil.generateJwtToken(UUID.fromString("21a56393-b6ef-404b-8a41-65703313e9f4"));
     *   System.out.println(token);
     */
    @Test
    void testLoadUserByToken() {
        //Decoded token:
        /*
        {
            "sub": "Example",
            "exp": 4765132800,
            "iss": "Example Tech",
            "https://app.example.com/roles": [
                "BORROWER"
            ],
            "https://app.example.com/metadata": {
                "user_uuid": "21a56393-b6ef-404b-8a41-65703313e9f4"
            }
        }
        */

        final String token = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJFeGFtcGxlIiwiZXhwIjo0NzY1MTMyODAwLCJpc3MiOiJFeGFtcGxlIF" +
                "RlY2giLCJodHRwczovL2FwcC5leGFtcGxlLmNvbS9yb2xlcyI6WyJCT1JST1dFUiJdLCJodHRwczovL2FwcC5leGFtcGxlLmNvbS" +
                "9tZXRhZGF0YSI6eyJ1c2VyX3V1aWQiOiIyMWE1NjM5My1iNmVmLTQwNGItOGE0MS02NTcwMzMxM2U5ZjQifX0.QVp4HOz5sNmT37" +
                "cNTbqAke7SEvFk6IMJKB685_wVq-o6RZzUD54xANeeYAR_hh69wSc52dB-2uQFbcjtHOi0QGI8hudC0yIeESlb0L9gZTCrr3nsRr" +
                "o70BDmBtgvUVigS9sNw5Ja29hmkkQ96WYjxyBf8qAU8hdYAMpgo7rs-p3wVxW5eyjk0MmWzufVF3gu2IqHwnncS7O7b2_lDvQWpx" +
                "KKqkJIXkMzh98eEgvB43FobkrvRG38f4cbhYFDo4cHUzcprF4AN9db_qWHxnz3zYlX4Bfww-9yVJU7lD3kjZeRBAvYUHLkBMwpT3" +
                "Tg_SQ0qAP1v4tJqmRHWmyGmSr0zg";

        JWTUser jwtUser = JWTService.decodeJWTUser(token);
        assertThat(jwtUser).isNotNull();
        assertThat(jwtUser.getUserId()).isEqualTo(UUID.fromString("21a56393-b6ef-404b-8a41-65703313e9f4"));
    }

    @Test
    void when_tokenGeneratedWithMetadataAndUserUuidAndRoles_thenSuccessValidation() {
        UUID userUuid = UUID.fromString(USER_ID_STR);
        String token = JWTTokenUtil.generateJwtToken(userUuid);

        JWTUser user = JWTService.decodeJWTUser(token);
        assertEquals(
                USER_ID_STR,
                user.getUserId().toString(),
                "Field 'userUuid' in token is not equal with original UUID."
        );

        DecodedJWT decodedJWT = JWT.decode(token);
        assertFalse(decodedJWT.getClaim(METADATA).isMissing());

        Object userUuidFromToken = decodedJWT.getClaim(METADATA).asMap().get(USER_UUID);
        assertFalse(userUuidFromToken == null || Strings.isNullOrEmpty(userUuidFromToken.toString()));

        assertFalse(decodedJWT.getClaim(ROLES) == null || decodedJWT.getClaim(ROLES).asList(String.class) == null);
    }

    @Test
    void when_tokenIsEmpty_thenValidationFails() {
        String emptyToken = "";
        assertNull(JWTService.decodeJWTUser(emptyToken));
    }

    @Test
    void when_tokenDoesNotContainMetadata_thenValidationFails() {
        String tokenWithoutMetadata = generateTokenWithoutMetadata();
        assertNull(JWTService.decodeJWTUser(tokenWithoutMetadata));
    }

    @Test
    void when_tokenDoesNotContainUserUuid_thenValidationFails() {
        String tokenWithoutUserUuid = generateTokenWithoutUserUuid();
        assertNull(JWTService.decodeJWTUser(tokenWithoutUserUuid));
    }

    @Test
    void when_tokenDoesNotContainRoles_thenValidationFails() {
        String tokenWithoutRoles = generateTokenWithoutRoles(USER_ID_STR);
        assertNull(JWTService.decodeJWTUser(tokenWithoutRoles));
    }


    //PRIVATE METHODS
    private String generateTokenWithoutMetadata() {
        return Jwts.builder()
                .setSubject("Example")
                .setExpiration(Date.from(Instant.ofEpochMilli(4765132800000L)))
                .setIssuer("Example Tech")
                .addClaims(generateClaimsWithoutMetadata())
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .compact();
    }

    private static Map<String, Object> generateClaimsWithoutMetadata() {
        String[] roles = {"BORROWER"};
        Map<String, Object> claims = new HashMap<>();
        claims.put(ROLES, roles);
        return claims;
    }

    private String generateTokenWithoutUserUuid() {
        return Jwts.builder()
                .setSubject("Example")
                .setExpiration(Date.from(Instant.ofEpochMilli(4765132800000L)))
                .setIssuer("Example Tech")
                .addClaims(generateClaimsWithoutUserUuid())
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .compact();
    }

    private static Map<String, Object> generateClaimsWithoutUserUuid() {
        String[] roles = {"BORROWER"};
        Map<String, Object> claims = new HashMap<>();
        claims.put(METADATA, new HashMap<>());
        claims.put(ROLES, roles);
        return claims;
    }

    private String generateTokenWithoutRoles(String userId) {
        return Jwts.builder()
                .setSubject("Example")
                .setExpiration(Date.from(Instant.ofEpochMilli(4765132800000L)))
                .setIssuer("Example Tech")
                .addClaims(Map.of(METADATA, Map.of(METADATA_USER_UUID, userId)))
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .compact();
    }

}