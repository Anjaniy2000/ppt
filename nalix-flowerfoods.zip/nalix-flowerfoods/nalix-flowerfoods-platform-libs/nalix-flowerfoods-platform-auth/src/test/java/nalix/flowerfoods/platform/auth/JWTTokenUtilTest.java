package nalix.flowerfoods.platform.auth;

import static org.assertj.core.api.Assertions.assertThat;
import static nalix.flowerfoods.platform.auth.testutils.JWTTokenUtil.generateJwtToken;
import static nalix.flowerfoods.platform.auth.testutils.JWTTokenUtil.getClaims;

import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class JWTTokenUtilTest {
  @Test
  @DisplayName("generateJwtToken() should return valid token")
  void testGenerateJwtToken() {
    var userId = UUID.randomUUID();
    var jwt = generateJwtToken(userId);
    var jwtBody = getClaims(jwt).getBody().toString();

    assertThat(jwtBody.contains("user_uuid=" + userId)).isTrue();
    assertThat(jwtBody.contains("roles=[BORROWER]")).isTrue(); // This should match String[] roles in JWTTokenUtil
  }
}
