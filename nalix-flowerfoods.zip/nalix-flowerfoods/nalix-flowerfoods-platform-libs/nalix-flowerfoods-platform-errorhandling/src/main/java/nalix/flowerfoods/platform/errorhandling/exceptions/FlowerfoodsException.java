package nalix.flowerfoods.platform.errorhandling.exceptions;


import com.google.rpc.Status;
import com.netflix.graphql.types.errors.ErrorType;
import com.netflix.graphql.types.errors.TypedGraphQLError;
import java.util.Objects;

public abstract class FlowerfoodsException extends RuntimeException {

    private final String description;
    public abstract Status toStatus();

    public FlowerfoodsException() {
        super("No Error Description");
        this.description = "No Error Description";
    }

    public FlowerfoodsException(String description) {
        super(description);
        this.description = description;
    }

    public TypedGraphQLError toTypedGraphQLError(){
        return TypedGraphQLError.newBuilder()
                .errorType(ErrorType.UNKNOWN)
                .build();
    }

    public String getDescription() {
        return description;
    }

    public boolean isRetryable() {
        return false;
    };

}
