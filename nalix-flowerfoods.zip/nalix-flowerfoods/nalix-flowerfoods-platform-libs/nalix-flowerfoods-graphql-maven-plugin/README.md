# Domain Graph Maven Plugin

This plugin generates a GraphQL remoting layer.
