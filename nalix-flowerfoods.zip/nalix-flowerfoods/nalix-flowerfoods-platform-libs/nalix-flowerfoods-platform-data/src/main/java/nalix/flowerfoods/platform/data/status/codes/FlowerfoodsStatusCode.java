package nalix.flowerfoods.platform.data.status.codes;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.List;
import org.immutables.value.Value.Derived;
import org.immutables.value.Value.Immutable;

/**
 * The idea behind this class is to give composable status codes
 * i.e. transaction::check::mitek::nsf
 * Gives improved readability over just enums when it traverses our services
 */

@Immutable
@JsonSerialize(as = ImmutableFlowerfoodsStatusCode.class)
@JsonDeserialize(as = ImmutableFlowerfoodsStatusCode.class)
public abstract class FlowerfoodsStatusCode {
  public abstract List<String> tags();

  @Override
  @Derived
  public String toString() {
    return String.join("::", tags());
  }

  public static FlowerfoodsStatusCode fromString(String joinedTags) {
    return fromStrings(joinedTags.split("::"));
  }

  public static FlowerfoodsStatusCode fromStrings(String... tags) {
    var code = ImmutableFlowerfoodsStatusCode.builder();
    code.addTags(tags);
    return code.build();
  }
}
