package nalix.flowerfoods.platform.data.status.codes;

/**
 * These builders are used so that services that import the status code pattern can start off with
 * consistent builders.
 */
public class BaseStatusCodes {
  public static final ImmutableFlowerfoodsStatusCode.Builder TRANSACTION_BASE = ImmutableFlowerfoodsStatusCode.
      builder()
      .addTags("transaction");
  public static final ImmutableFlowerfoodsStatusCode.Builder ACCOUNT_BASE = ImmutableFlowerfoodsStatusCode.
      builder()
      .addTags("account");
}
