package nalix.flowerfoods.platform.data;

public enum Currency {
  CURRENCY_UNSPECIFIED,
  USD,
  CAD
}