package nalix.flowerfoods.platform.data.numbers.integer;

public abstract class FlowerfoodsInt {

  final int value;

  protected FlowerfoodsInt(int i) {
    this.value = i;
  }

  public int value() {
    return value;
  }
}
