package nalix.flowerfoods.platform.aws.v2.core;

import software.amazon.awssdk.regions.providers.AwsProfileRegionProvider;
import software.amazon.awssdk.regions.providers.AwsRegionProviderChain;
import software.amazon.awssdk.regions.providers.InstanceProfileRegionProvider;
import software.amazon.awssdk.regions.providers.SystemSettingsRegionProvider;

public class FlowerfoodsAwsRegionProviderChain extends AwsRegionProviderChain {

  public FlowerfoodsAwsRegionProviderChain() {
    super(
        new SystemSettingsRegionProvider(),
        new AwsProfileRegionProvider(),
        new InstanceProfileRegionProvider(),
        new DefaultRegionProvider());
  }
}
