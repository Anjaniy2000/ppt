package nalix.flowerfoods.platform.aws.v2.core;

import com.amazonaws.auth.*;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;

public class FlowerfoodsAWSCredentialsProviderChain extends AWSCredentialsProviderChain {

    private static final FlowerfoodsAWSCredentialsProviderChain INSTANCE
            = new FlowerfoodsAWSCredentialsProviderChain();

    public FlowerfoodsAWSCredentialsProviderChain() {
        super(new EnvironmentVariableCredentialsProvider(),
                new SystemPropertiesCredentialsProvider(),
                WebIdentityTokenCredentialsProvider.create(),
                new ProfileCredentialsProvider(),
                new LocalStackCredentialsProvider()
        );
    }

    public static FlowerfoodsAWSCredentialsProviderChain getInstance() {
        return INSTANCE;
    }
}
