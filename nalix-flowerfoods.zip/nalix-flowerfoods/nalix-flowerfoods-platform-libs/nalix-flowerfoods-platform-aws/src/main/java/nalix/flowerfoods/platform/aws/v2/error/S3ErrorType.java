package nalix.flowerfoods.platform.aws.v2.error;

public enum S3ErrorType {
    JSON_PARSING,
    AWS,
    JSON_STREAMING
}
