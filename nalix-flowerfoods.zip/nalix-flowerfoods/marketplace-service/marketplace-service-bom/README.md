# marketplace-service-bom

A [Bill of Materials](https://www.baeldung.com/spring-maven-bom) for the Marketplace Service.

## Use

To use any of the modules from this project, you should include its Bill of Materials in the parent pom of your service:

```xml
    <properties>
        <nalix.flowerfoods.version>VERSION</nalix.flowerfoods.version>
    </properties>

    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>nalix.flowerfoods</groupId>
                <artifactId>marketplace-service-bom</artifactId>
                <version>${nalix.flowerfoods.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>
```