package nalix.flowerfoods.marketplace.service.core;

import com.google.api.gax.core.FixedCredentialsProvider;
import com.google.auth.Credentials;
import com.google.cloud.vision.v1.*;
import com.google.protobuf.ByteString;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GoogleImageAnnotator {
    private final Credentials credentials;

    public GoogleImageAnnotator(Credentials credentials) {
        this.credentials = credentials;
    }

    public BatchAnnotateImagesResponse getResponse(ByteString imageBytes) {

        BatchAnnotateImagesResponse response = null;
        try {
            ImageAnnotatorSettings imageAnnotatorSettings =
                ImageAnnotatorSettings.newBuilder()
                                      .setCredentialsProvider(FixedCredentialsProvider.create(this.credentials))
                                      .build();
            ImageAnnotatorClient imageAnnotatorClient = ImageAnnotatorClient.create(imageAnnotatorSettings);
            Image image = Image.newBuilder().setContent(imageBytes).build();
            List<AnnotateImageRequest> requests = new ArrayList<>();
            AnnotateImageRequest request =
                AnnotateImageRequest.newBuilder()
                                    .addFeatures(Feature.newBuilder().setType(Feature.Type.TEXT_DETECTION))
                                    .setImage(image)
                                    .build();
            requests.add(request);
            response = imageAnnotatorClient.batchAnnotateImages(requests);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return response;
    }
}



