package nalix.flowerfoods.marketplace.service.core.enums;

public enum ProductStatus {
    AVAILABLE,
    UNAVAILABLE,
    BID_RECEIVED,
    PENDING
}
