package nalix.flowerfoods.marketplace.service.core.config;

import com.google.auth.Credentials;
import com.google.auth.oauth2.ServiceAccountCredentials;
import nalix.flowerfoods.marketplace.service.core.util.ReadPKCS8Pem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import java.net.URI;
import java.security.PrivateKey;

@Configuration
public class GoogleCloudConfig {
    private static final Logger logger = LoggerFactory.getLogger(GoogleCloudConfig.class);

    private final String                    projectId;
    private final String                    privateKeyId;
    private final PrivateKey                privateKey;
    private final String                    clientEmail;
    private final String                    clientId;
    private final URI                       tokenServerUri;
    private       ServiceAccountCredentials credentials;

    public GoogleCloudConfig(Environment env) {
        this.projectId = env.getProperty("gcloud-service-account.project-id");
        this.privateKeyId = env.getProperty("gcloud-service-account.project-private-key-id");
        this.privateKey = ReadPKCS8Pem.toKey(env.getProperty("gcloud-service-account.private-key"));
        this.clientEmail = env.getProperty("gcloud-service-account.client-email");
        this.clientId = env.getProperty("gcloud-service-account.client-id");
        this.tokenServerUri = URI.create(env.getProperty("gcloud-service-account.token-uri"));
    }

    @Bean
    @ConditionalOnProperty(name = "mock.gcloud-service-account", havingValue = "false", matchIfMissing = true)
    public Credentials credentials() {
        this.credentials = ServiceAccountCredentials
            .newBuilder()
            .setProjectId(this.projectId)
            .setPrivateKeyId(this.privateKeyId)
            .setPrivateKey(this.privateKey)
            .setClientEmail(this.clientEmail)
            .setClientId(this.clientId)
            .setTokenServerUri(this.tokenServerUri)
            .build();
        return this.credentials;
    }
}
