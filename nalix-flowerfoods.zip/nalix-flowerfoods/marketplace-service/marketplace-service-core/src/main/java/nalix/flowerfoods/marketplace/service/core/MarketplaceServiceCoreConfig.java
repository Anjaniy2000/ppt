package nalix.flowerfoods.marketplace.service.core;
import nalix.flowerfoods.marketplace.service.persistence.MarketplaceServicePersistenceConfig;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({
        MarketplaceServicePersistenceConfig.class,
})
@ComponentScan
public class MarketplaceServiceCoreConfig {

}