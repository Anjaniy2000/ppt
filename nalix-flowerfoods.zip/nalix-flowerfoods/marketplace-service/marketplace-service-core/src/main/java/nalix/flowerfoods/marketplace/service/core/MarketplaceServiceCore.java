package nalix.flowerfoods.marketplace.service.core;
import com.google.cloud.vision.v1.BatchAnnotateImagesResponse;
import com.google.protobuf.ByteString;
import nalix.flowerfoods.marketplace.service.core.enums.ProductStatus;
import nalix.flowerfoods.marketplace.service.core.support.DistanceCalculator;
import nalix.flowerfoods.marketplace.service.persistence.entities.AccountEntity;
import nalix.flowerfoods.marketplace.service.persistence.repositories.AccountRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import nalix.flowerfoods.marketplace.service.api.v1.MarketplaceService;
import nalix.flowerfoods.marketplace.service.core.support.Converters;
import nalix.flowerfoods.marketplace.service.grpc.v1.*;
import nalix.flowerfoods.marketplace.service.persistence.entities.MarketplaceEntity;
import nalix.flowerfoods.marketplace.service.persistence.repositories.MarketplaceRepository;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import static nalix.flowerfoods.marketplace.service.core.support.Converters.convert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class MarketplaceServiceCore implements MarketplaceService {
    private final MarketplaceRepository marketplaceRepository;
    private final AccountRepository accountRepository;
    private final GoogleImageAnnotator googleImageAnnotator;
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final int DEFAULT_PRODUCT_LIST_SIZE = 20;

    public MarketplaceServiceCore(MarketplaceRepository marketplaceRepository, AccountRepository accountRepository, GoogleImageAnnotator googleImageAnnotator) {
            this.marketplaceRepository = marketplaceRepository;
            this.accountRepository = accountRepository;
            this.googleImageAnnotator = googleImageAnnotator;
    }

    @Override
    public CreateMarketplaceResponse createMarketplace(MarketplaceDto marketplace) {
        MarketplaceEntity marketplaceEntity = Converters.convert(marketplace);
        MarketplaceEntity saved = marketplaceRepository.save(marketplaceEntity);
        MarketplaceDto converted = convert(saved);

        return CreateMarketplaceResponse.newBuilder()
                                        .setMarketplace(converted)
                                        .build();


    }

    @Override
    public GetMarketplacesResponse getMarketplaces(GetMarketplacesRequest request) {
        logger.debug("Inside getMarketplaces...");
        int pageSize = (request.getPageSize() > 0) ? request.getPageSize() : DEFAULT_PRODUCT_LIST_SIZE;
        pageSize = Math.min(pageSize, 100);
        Pageable pageable = null;
        Page<MarketplaceEntity> page = null;
        List<MarketplaceEntity> filterdList = new ArrayList<>();

        if (request.getSortBy().isEmpty() && request.getSortDirection().isEmpty()) {
            logger.debug("Inside getMarketplaces. No sorting passed in. Defaulting it to created date descending...");
            pageable = PageRequest.of(request.getStartPage(), pageSize).withSort(Sort.by(Sort.Direction.DESC, "created"));
        } else {
            logger.debug("Inside getMarketplaces. Sorting passed in. Sort Direction: '{}', Sort Key: '{}'", request.getSortDirection(), request.getSortBy());
            if(request.getSortDirection().equals("ASC")) {
                pageable = PageRequest.of(request.getStartPage(), pageSize).withSort(Sort.by(Sort.Direction.ASC, request.getSortBy()));
            } else {
                pageable = PageRequest.of(request.getStartPage(), pageSize).withSort(Sort.by(Sort.Direction.DESC, request.getSortBy()));
            }
        }

        if (request.getIsAvailable().equals("") || request.getIsAvailable().equals("true")) {
            page = marketplaceRepository.getMarketplaces(request.getName(), request.getType(), true, pageable);
        } else {
            page = marketplaceRepository.getMarketplaces(request.getName(), request.getType(), false, pageable);
        }

        if (request.getAccountLatitude() != 0.0 && request.getAccountLongitude() != 0.0) {
            logger.debug("Inside getMarketplaces. Account Lat/Long passed in. Lat: '{}', Long: '{}'", request.getAccountLatitude(), request.getAccountLongitude());
            for(MarketplaceEntity marketplaceEntity : page) {
                Double distance = DistanceCalculator.calculateDistance(
                    marketplaceEntity.getLatitude(),
                    marketplaceEntity.getLongitude(),
                    request.getAccountLatitude(),
                    request.getAccountLongitude());
                if (distance < 1000.0) {
                    marketplaceEntity.setDistance(distance + " " + "miles away from you");
                    filterdList.add(marketplaceEntity);
                }
            }
            List<MarketplaceDto> marketplaces = filterdList.stream()
                                                           .map(Converters::convert)
                                                           .collect(Collectors.toList());

            return GetMarketplacesResponse.newBuilder()
                                          .addAllMarketplace(marketplaces)
                                          .setHasNext(page.hasNext())
                                          .setHasPrevious(page.hasPrevious())
                                          .setNextPage(page.getPageable().next().getPageNumber())
                                          .setTotalElements(page.getTotalElements())
                                          .setTotalPages(page.getTotalPages())
                                          .build();
        } else {
            logger.debug("Inside getMarketplaces. No Account Lat/Long passed in.");
            List<MarketplaceDto> marketplaces = page.stream()
                                                    .map(Converters::convert)
                                                    .collect(Collectors.toList());
            GetMarketplacesResponse getMarketplacesResponse = GetMarketplacesResponse.newBuilder()
                                   .addAllMarketplace(marketplaces)
                                   .setHasNext(page.hasNext())
                                   .setHasPrevious(page.hasPrevious())
                                   .setNextPage(page.getPageable().next().getPageNumber())
                                   .setTotalElements(page.getTotalElements())
                                   .setTotalPages(page.getTotalPages())
                                   .build();
            logger.debug("Inside getMarketplaces. Returning results...");
            return getMarketplacesResponse;
        }
    }

    @Override
    public GetMarketplaceResponse getMarketplace(GetMarketplaceRequest request) {
        Optional<MarketplaceEntity> response = marketplaceRepository.findById(UUID.fromString(request.getId()));
        if (response.isPresent()) {
            MarketplaceEntity entity = response.get();
            return GetMarketplaceResponse.newBuilder()
                                         .setMarketplace(convert(entity))
                                         .build();
        }
        return null;
    }

    @Override
    public UpdateMarketplaceResponse updateMarketplace(MarketplaceDto marketplace) {
        Date purchasedDate = null;
        UUID purchasedBy = null;
        String status = marketplace.getStatus();

        if (!marketplace.getPurchasedBy()
                       .equals("")){
            purchasedDate = new Date();
            purchasedBy = UUID.fromString(marketplace.getPurchasedBy());
            status = ProductStatus.UNAVAILABLE.toString();
        }

        if (marketplace.hasId()) {
            UUID id = UUID.fromString(marketplace.getId().getValue());
            Optional<MarketplaceEntity> entity = marketplaceRepository.findById(id);
            if (entity.isPresent()) {
                MarketplaceEntity marketplaceEntity = entity.get();

                if(!(marketplace.getName().equals(""))){
                    marketplaceEntity.setName(marketplace.getName());
                }

                if(!(marketplace.getDescription().equals(""))){
                    marketplaceEntity.setDescription(marketplace.getDescription());
                }

                if(!(marketplace.getType().equals(""))){
                    marketplaceEntity.setType(marketplace.getType());
                }

                if(!(marketplaceEntity.getIs_available() == marketplace.getIsAvailable())){
                    marketplaceEntity.setIs_available(marketplace.getIsAvailable());
                }

                if(marketplace.getQuantity() > 0 && marketplace.getQuantity() != marketplaceEntity.getQuantity()){
                    marketplaceEntity.setQuantity(marketplace.getQuantity());
                }

                if(!(marketplace.getQuantityUnit().equals(""))){
                    marketplaceEntity.setQuantity_unit(marketplace.getQuantityUnit());
                }

                if((marketplace.getPrice() > 0) && marketplace.getPrice() != marketplaceEntity.getPrice()){
                    marketplaceEntity.setPrice(marketplace.getPrice());
                }

                if((marketplace.getOriginalPrice() > 0) && marketplace.getOriginalPrice() != marketplaceEntity.getOriginal_price()){
                    marketplaceEntity.setOriginal_price(marketplace.getOriginalPrice());
                }

                if(!(marketplace.getLatitude() == 0.0) && marketplace.getLatitude() != marketplaceEntity.getLatitude()){
                    marketplaceEntity.setLatitude(marketplace.getLatitude());
                }

                if(!(marketplace.getLongitude() == 0.0) && marketplace.getLongitude() != marketplaceEntity.getLongitude()){
                    marketplaceEntity.setLongitude(marketplace.getLongitude());
                }

                if(!(marketplace.getDistance().equals(""))){
                    marketplaceEntity.setDistance(marketplace.getDistance());
                }

                if(marketplace.getWasteProbability() > 0.0 &&  marketplace.getWasteProbability() != marketplaceEntity.getWaste_probability()){
                    marketplaceEntity.setWaste_probability(marketplace.getWasteProbability());
                }

                marketplaceEntity.setPurchased_by(purchasedBy);
                marketplaceEntity.setPurchased_date(purchasedDate);
                marketplaceEntity.setStatus(status);

                if(!(marketplace.getLocation().equals("")) && !(marketplace.getLocation().equals(marketplaceEntity.getLocation()))){
                    marketplaceEntity.setLocation(marketplace.getLocation());
                }

                if(!(marketplace.getAvailableDate().equals("")) &&  !(marketplace.getAvailableDate().equals(marketplaceEntity.getAvailable_date()))){
                    marketplaceEntity.setAvailable_date(marketplace.getAvailableDate());
                }

                if(marketplace.getPriceIncrease() > 0.0 && marketplace.getPriceIncrease() != marketplaceEntity.getPrice_increase()){
                    marketplaceEntity.setPrice_increase(marketplace.getPriceIncrease());
                }

                if(marketplace.getRating() >= 0 && marketplace.getRating() != marketplaceEntity.getRating()){
                    marketplaceEntity.setRating(marketplace.getRating());
                }

                if((!marketplace.getSku().equals("")) && (!marketplace.getSku().equals(marketplaceEntity.getSku())) && marketplace.getSku().length() == 8){
                    marketplaceEntity.setSku(marketplace.getSku());
                }

                if(!(marketplace.getImagesCount() == 0)){
                    marketplaceEntity.getImages().clear();
                    List<String> updatedImages = new ArrayList<>(marketplace.getImagesList());
                    marketplaceEntity.setImages(updatedImages);
                }

                if(marketplace.getMinimumBid() > 0.0 && marketplace.getMinimumBid() != marketplaceEntity.getMinimum_bid()){
                    marketplaceEntity.setMinimum_bid(marketplace.getMinimumBid());
                }

                if(marketplace.getReservePrice() > 0.0 && marketplace.getReservePrice() != marketplaceEntity.getReserve_price()){
                    marketplaceEntity.setReserve_price(marketplace.getReservePrice());
                }

                if(!(marketplace.getBidTimeframe().equals("")) && !marketplace.getBidTimeframe()
                                                                              .equals(marketplaceEntity.getBid_timeframe())){
                    marketplaceEntity.setBid_timeframe(marketplace.getBidTimeframe());
                }

                if(!(marketplace.getAllergensCount() == 0)){
                    marketplaceEntity.getAllergens().clear();
                    List<String> updatedAllergens = new ArrayList<>(marketplace.getAllergensList());
                    marketplaceEntity.setAllergens(updatedAllergens);
                }

                if(!(marketplace.getPriceUnit().equals("") && !(marketplace.getPriceUnit().equals(marketplaceEntity.getPrice_unit())))){
                    marketplaceEntity.setPrice_unit(marketplace.getPriceUnit());
                }

                if(!(marketplace.getAutoPricing() == marketplaceEntity.getAuto_pricing())){
                    marketplaceEntity.setAuto_pricing(marketplace.getAutoPricing());
                }

                if(marketplace.getHighestBid() > marketplaceEntity.getHighest_bid()){
                    marketplaceEntity.setHighest_bid(marketplace.getHighestBid());
                    marketplaceEntity.setTotal_bids(marketplaceEntity.getTotal_bids() + 1);
                    marketplaceEntity.setBidder_id(UUID.fromString(marketplace.getBidderId()));
                    marketplaceEntity.setStatus(ProductStatus.BID_RECEIVED.toString());
                }

                if(!(marketplace.getExpiryDate().equals("")) && !(marketplace.getExpiryDate().equals(marketplaceEntity.getExpiry_date()))){
                    marketplaceEntity.setExpiry_date(marketplace.getExpiryDate());
                }
                marketplaceRepository.save(marketplaceEntity);
                return UpdateMarketplaceResponse.newBuilder().setMarketplace(convert(marketplaceEntity)).build();
            }
        }
        return UpdateMarketplaceResponse.getDefaultInstance();
    }

    @Override
    public CreateAccountResponse createAccount(AccountDto account) {
        AccountEntity accountEntity = convert(account);
        return CreateAccountResponse.newBuilder()
                                    .setAccount(convert(accountRepository.save(accountEntity)))
                                    .build();
    }

    @Override
    public GetAccountsResponse getAccounts(GetAccountsRequest request) {
        int pageSize = Math.min(Math.max(request.getPageSize(), 10), 100);
        Pageable pageable = null;
        Page<AccountEntity> page = null;

        if (request.getSortBy().isEmpty() && request.getSortDirection().isEmpty()) {
            pageable = PageRequest.of(request.getStartPage(), pageSize);
        } else {
            if(request.getSortDirection().equals("ASC")){
                pageable = PageRequest.of(request.getStartPage(), pageSize).withSort(Sort.by(Sort.Direction.ASC, request.getSortBy()));
            } else {
                pageable = PageRequest.of(request.getStartPage(), pageSize).withSort(Sort.by(Sort.Direction.DESC, request.getSortBy()));
            }
        }
        page = accountRepository.getAccounts(request.getName(), request.getEmail(), request.getImageUrl(), pageable);

        List<AccountDto> accounts = page.stream()
                                                .map(Converters::convert)
                                                .collect(Collectors.toList());
        return GetAccountsResponse.newBuilder()
                                      .addAllAccount(accounts)
                                      .setHasNext(page.hasNext())
                                      .setHasPrevious(page.hasPrevious())
                                      .setNextPage(page.getPageable().next().getPageNumber())
                                      .setTotalElements(page.getTotalElements())
                                      .setTotalPages(page.getTotalPages())
                                      .build();
    }

    @Override
    public GetAccountResponse getAccount(GetAccountRequest request) {
        Optional<AccountEntity> response = accountRepository.findById(UUID.fromString(request.getId()));
        if (response.isPresent()) {
            AccountEntity accountEntity = response.get();
            return GetAccountResponse.newBuilder()
                                     .setAccount(convert(accountEntity))
                                     .build();
        }
        return null;
    }

    @Override
    public UpdateAccountResponse updateAccount(AccountDto account) {
        if (account.hasId()) {
            UUID id = UUID.fromString(account.getId().getValue());
            Optional<AccountEntity> response = accountRepository.findById(id);
            if(response.isPresent()){
                AccountEntity accountEntity = response.get();
                accountEntity.setName(account.getName());
                accountEntity.setEmail(account.getEmail());
                accountEntity.setImage_url(account.getImageUrl());
                accountEntity.setLatitude(account.getLatitude());
                accountEntity.setLongitude(account.getLongitude());
                accountEntity.setPurchased_stat(account.getPurchasedStat());
                accountEntity.setMoney_saved_stat(account.getMoneySavedStat());
                accountEntity.setWaste_saved_stat(account.getWasteSavedStat());
                accountRepository.save(accountEntity);
                return UpdateAccountResponse.newBuilder()
                                            .setAccount(convert(accountEntity))
                                            .build();
            }
        }
        return UpdateAccountResponse.getDefaultInstance();
    }

    @Override
    public GetIngredientsResponse getIngredients(GetIngredientsRequest getIngredientsRequest) {
        String imageBase64 = getIngredientsRequest.getImage();
        byte[] imageData = Base64.getDecoder()
                                 .decode(imageBase64);
        ByteString imageBytes = ByteString.copyFrom(imageData);
        BatchAnnotateImagesResponse imageAnnotationResponse = this.googleImageAnnotator.getResponse(imageBytes);
        String description = imageAnnotationResponse.getResponsesList()
                                                    .get(0)
                                                    .getTextAnnotationsList()
                                                    .get(0)
                                                    .getDescription();

        String newDescription  = description.replace("\n", " ");
        Pattern pattern = Pattern.compile("Ingredients: (\\w.*?([.]))", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(newDescription);
        GetIngredientsResponse.Builder getIngredientsResponse = GetIngredientsResponse.newBuilder();

        if(matcher.find()) {
            String ingredientsText = matcher.group(1);

            // Split ingredients string on commas and newlines
            String[] splitIngredients = ingredientsText.split("[.]|,|\\n");

            // Clean each ingredient
            for(String ingredient : splitIngredients){
                getIngredientsResponse.addIngredient(ingredient);
            }
        }

        return getIngredientsResponse.build();
    }

    @Override
    public DeleteMarketplaceResponse deleteMarketplace(DeleteMarketplaceRequest request) {
        Optional<MarketplaceEntity> response = marketplaceRepository.findById(UUID.fromString(request.getId()));
        if (response.isPresent()) {
            MarketplaceEntity entity = response.get();
            marketplaceRepository.deleteById(UUID.fromString(request.getId()));
            return DeleteMarketplaceResponse.newBuilder()
                                            .setMarketplace(convert(entity))
                                            .build();
        }
        return null;
    }
}
