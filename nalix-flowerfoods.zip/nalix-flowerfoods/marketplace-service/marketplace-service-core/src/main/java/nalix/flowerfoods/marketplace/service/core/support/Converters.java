package nalix.flowerfoods.marketplace.service.core.support;

import com.google.protobuf.StringValue;
import nalix.flowerfoods.marketplace.service.core.enums.ProductStatus;
import nalix.flowerfoods.marketplace.service.grpc.v1.AccountDto;
import nalix.flowerfoods.marketplace.service.grpc.v1.MarketplaceDto;
import nalix.flowerfoods.marketplace.service.persistence.entities.AccountEntity;
import nalix.flowerfoods.marketplace.service.persistence.entities.MarketplaceEntity;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class Converters {

    public static MarketplaceDto convert(MarketplaceEntity marketplaceEntity) {
        String bidderId;
        if(marketplaceEntity.getBidder_id() == null){
            bidderId = "";
        } else{
            bidderId = marketplaceEntity.getBidder_id().toString();
        }
        MarketplaceDto.Builder builder = MarketplaceDto.newBuilder()
                                        .setId(StringValue.of(marketplaceEntity.getId().toString()))
                                        .setName(marketplaceEntity.getName())
                                        .setDescription(marketplaceEntity.getDescription())
                                        .setType(marketplaceEntity.getType())
                                        .setIsAvailable(marketplaceEntity.getIs_available())
                                        .setQuantity(marketplaceEntity.getQuantity())
                                        .setQuantityUnit(marketplaceEntity.getQuantity_unit())
                                        .setPrice(marketplaceEntity.getPrice())
                                        .setOriginalPrice(marketplaceEntity.getOriginal_price())
                                        .setLatitude(marketplaceEntity.getLatitude())
                                        .setLongitude(marketplaceEntity.getLongitude())
                                        .setDistance(marketplaceEntity.getDistance())
                                        .setWasteProbability(marketplaceEntity.getWaste_probability())
                                        .setPurchasedBy(String.valueOf(marketplaceEntity.getPurchased_by()))
                                        .setPurchasedDate(String.valueOf(marketplaceEntity.getPurchased_date()))
                                        .setLocation(marketplaceEntity.getLocation())
                                        .setAvailableDate(marketplaceEntity.getAvailable_date())
                                        .setPriceIncrease(marketplaceEntity.getPrice_increase())
                                        .setRating(marketplaceEntity.getRating())
                                        .addAllImages(marketplaceEntity.getImages())
                                        .setSku(truncateSku(marketplaceEntity.getSku()))
                                        .setMinimumBid(marketplaceEntity.getMinimum_bid())
                                        .setReservePrice(marketplaceEntity.getReserve_price())
                                        .setBidTimeframe(marketplaceEntity.getBid_timeframe())
                                        .setTotalBids(marketplaceEntity.getTotal_bids())
                                        .setHighestBid(marketplaceEntity.getHighest_bid())
                                        .setBidderId(bidderId)
                                        .addAllAllergens(marketplaceEntity.getAllergens())
                                        .setPriceUnit(marketplaceEntity.getPrice_unit())
                                        .setAutoPricing(marketplaceEntity.getAuto_pricing())
                                        .setStatus(marketplaceEntity.getStatus())
                                        .setExpiryDate(marketplaceEntity.getExpiry_date());
        return builder.build();
    }

    public static MarketplaceEntity convert(MarketplaceDto marketplace){
        MarketplaceEntity marketplaceEntity = null;
        Date purchasedDate = null;
        UUID purchasedBy = null;
        UUID bidderId = null;

        if(marketplace.getTotalBids() != 0 && marketplace.getHighestBid() != 0){
            bidderId = UUID.fromString(marketplace.getBidderId());
        }

        if(!marketplace
            .getPurchasedBy()
            .equals("")){
            purchasedBy = UUID.fromString(marketplace.getPurchasedBy());
            purchasedDate = new Date();
        }

        if (marketplace.hasId()) {
            marketplaceEntity = new MarketplaceEntity(
                                    UUID.fromString(marketplace.getId().getValue()),
                                    marketplace.getName(),
                                    marketplace.getDescription(),
                                    marketplace.getType(),
                                    marketplace.getIsAvailable(),
                                    marketplace.getQuantity(),
                                    marketplace.getQuantityUnit(),
                                    marketplace.getPrice(),
                                    marketplace.getOriginalPrice(),
                                    marketplace.getLatitude(),
                                    marketplace.getLongitude(),
                                    marketplace.getDistance(),
                                    marketplace.getWasteProbability(),
                                    purchasedBy,
                                    purchasedDate,
                                    marketplace.getLocation(),
                                    marketplace.getAvailableDate(),
                                    marketplace.getPriceIncrease(),
                                    marketplace.getRating(),
                                    marketplace.getImagesList(),
                                    marketplace.getSku(),
                                    marketplace.getMinimumBid(),
                                    marketplace.getReservePrice(),
                                    marketplace.getBidTimeframe(),
                                    marketplace.getTotalBids(),
                                    marketplace.getHighestBid(),
                                    bidderId,
                                    marketplace.getAllergensList(),
                                    marketplace.getPriceUnit(),
                                    marketplace.getAutoPricing(),
                                    marketplace.getStatus(),
                                    marketplace.getExpiryDate());
        } else {
            marketplaceEntity = new MarketplaceEntity(
                                    UUID.randomUUID(),
                                    marketplace.getName(),
                                    marketplace.getDescription(),
                                    marketplace.getType(),
                                    marketplace.getIsAvailable(),
                                    marketplace.getQuantity(),
                                    marketplace.getQuantityUnit(),
                                    marketplace.getPrice(),
                                    marketplace.getOriginalPrice(),
                                    marketplace.getLatitude(),
                                    marketplace.getLongitude(),
                                    marketplace.getDistance(),
                                    marketplace.getWasteProbability(),
                                    purchasedBy,
                                    purchasedDate,
                                    marketplace.getLocation(),
                                    marketplace.getAvailableDate(),
                                    marketplace.getPriceIncrease(),
                                    marketplace.getRating(),
                                    marketplace.getImagesList(),
                                    truncateSku(""),
                                    marketplace.getMinimumBid(),
                                    marketplace.getReservePrice(),
                                    marketplace.getBidTimeframe(),
                                    0,
                                    0.0F,
                                    bidderId,
                                    marketplace.getAllergensList(),
                                    marketplace.getPriceUnit(),
                                    marketplace.getAutoPricing(),
                                    ProductStatus.AVAILABLE.toString(),
                                    marketplace.getExpiryDate());
        }
        return marketplaceEntity;
    }

    private static String truncateSku (String sku) {
        if(sku.equals("")){
            return UUID.randomUUID().toString().substring(0,8).toUpperCase(Locale.ENGLISH);
        }
        else{
            return sku.substring(0,8).toUpperCase(Locale.ENGLISH);
        }

    }

    public static AccountDto convert(AccountEntity accountEntity){
        AccountDto.Builder builder = AccountDto.newBuilder()
            .setId(StringValue.of(accountEntity
                .getId()
                .toString()))
            .setName(accountEntity.getName())
            .setEmail(accountEntity.getEmail())
            .setImageUrl(accountEntity.getImage_url())
            .setLatitude(accountEntity.getLatitude())
            .setLongitude(accountEntity.getLongitude());
        return builder.build();
    }

    public static AccountEntity convert(AccountDto account){
        AccountEntity accountEntity = null;

        if(account.hasId()){
            accountEntity = new AccountEntity(
                UUID.fromString(account
                    .getId()
                    .getValue()),
                account.getName(),
                account.getEmail(),
                account.getImageUrl(),
                account.getLatitude(),
                account.getLongitude(),
                account.getPurchasedStat(),
                account.getMoneySavedStat(),
                account.getWasteSavedStat()
            );
        }
        else{
            accountEntity = new AccountEntity(
                UUID.randomUUID(),
                account.getName(),
                account.getEmail(),
                account.getImageUrl(),
                account.getLatitude(),
                account.getLongitude(),
                account.getPurchasedStat(),
                account.getMoneySavedStat(),
                account.getWasteSavedStat()
            );
        }
        return accountEntity;
    }

}
