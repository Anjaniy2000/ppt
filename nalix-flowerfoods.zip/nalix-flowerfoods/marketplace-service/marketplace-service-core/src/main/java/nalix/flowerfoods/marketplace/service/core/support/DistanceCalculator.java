package nalix.flowerfoods.marketplace.service.core.support;

import com.grum.geocalc.Coordinate;
import com.grum.geocalc.EarthCalc;
import com.grum.geocalc.Point;

public class DistanceCalculator {
    public static Double calculateDistance(Double marketplaceLatitude,
                                           Double marketplaceLongitude,
                                           Double accountLatitude,
                                           Double accountLongitude){

        Coordinate latitude = Coordinate.fromDegrees(marketplaceLatitude);
        Coordinate longitude = Coordinate.fromDegrees(marketplaceLongitude);
        Point marketplaceCoordinates = Point.at(latitude, longitude);

        latitude = Coordinate.fromDegrees(accountLatitude);
        longitude = Coordinate.fromDegrees(accountLongitude);
        Point accountCoordinates = Point.at(latitude, longitude);

        return (EarthCalc.haversine.distance(accountCoordinates, marketplaceCoordinates) * 0.00062137);
    }
}
