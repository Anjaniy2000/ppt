package nalix.flowerfoods.marketplace.service.integration.tests;

import com.google.protobuf.StringValue;
import nalix.flowerfoods.marketplace.service.persistence.repositories.AccountRepository;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import nalix.flowerfoods.marketplace.service.grpc.v1.*;
import nalix.flowerfoods.marketplace.service.persistence.repositories.MarketplaceRepository;
import java.net.URL;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


class MarketplaceServiceGrpcTest extends MarketplaceServiceBaseIT {

    private MarketplaceDto marketplaceDto;

    private AccountDto accountDtoOne;

    private AccountDto accountDtoTwo;

    private List<String> images;

    private List<String> allergens;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @BeforeEach
    void setup(){
        String encodedString = "";
        try {
            byte[] fileContent = FileUtils.readFileToByteArray(new ClassPathResource("testProductImage.jpg").getFile());
            encodedString = Base64.encodeBase64String(fileContent);
        } catch (Exception e) {
            e.printStackTrace();
        }

        images = List.of(
            encodedString
        );

        allergens = List.of(
            "Gluten",
            "Gluten",
            "Gluten"
        );

        marketplaceDto =  MarketplaceDto.newBuilder()
                                        .setName("Organic Whole Wheat")
                                        .setDescription("Whole Wheat")
                                        .setType("Raw Ingredients")
                                        .setIsAvailable(true)
                                        .setQuantity(20)
                                        .setQuantityUnit("LBS")
                                        .setPrice(100F)
                                        .setOriginalPrice(200F)
                                        .setLatitude(38.897147)
                                        .setLongitude(-77.043934)
                                        .setWasteProbability(2.5F)
                                        .setLocation("USA")
                                        .setAvailableDate("01/01/2021")
                                        .setPriceIncrease(25.0F)
                                        .setRating(3.5F)
                                        .addAllImages(images)
                                        .setMinimumBid(35.00F)
                                        .setReservePrice(30.00F)
                                        .setBidTimeframe("2 weeks")
                                        .addAllAllergens(allergens)
                                        .setPriceUnit("$")
                                        .setAutoPricing(true)
                                        .setExpiryDate("01/08/2021")
                                        .build();

        accountDtoOne =  AccountDto.newBuilder()
                                .setName("TCS")
                                .setEmail("tcs101tcs.com")
                                .setImageUrl("https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Tata_Consultancy_Services_Logo.svg/512px-Tata_Consultancy_Services_Logo.svg.png?20210617123944")
                                .setLatitude(38.897147)
                                .setLongitude(-77.043934)
                                .build();

        accountDtoTwo =  AccountDto.newBuilder()
                                   .setName("HCL")
                                   .setEmail("hcl101hcl.com")
                                   .setImageUrl("https://cached.imagescaler.hbpl.co.uk/resize/scaleWidth/952/cached.offlinehbpl.hbpl.co.uk/news/SUC/20220927102358_hcltech-copy-CUS.jpg")
                                   .setLatitude(38.897147)
                                   .setLongitude(-77.043934)
                                   .build();
    }

    @Test
    void test_createMarketplace() {
        CreateMarketplaceResponse response = client.createMarketplace(marketplaceDto);
        logger.info("createResponse: "  + "\n" + response.getMarketplace());
    }

    @Test
    void testPositive_getCreateAndGetMarketplace() {
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);

        GetMarketplaceResponse getResponse = client.getMarketplace(
            GetMarketplaceRequest.newBuilder()
                                 .setId(createResponse
                                     .getMarketplace()
                                     .getId()
                                     .getValue())
                                 .build()

        );

        assertThat(createResponse.getMarketplace()).isEqualTo(getResponse.getMarketplace());
    }

    @Test
    void testNegative_getCreateAndGetMarketplace() {
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);

        GetMarketplaceResponse getResponse = client.getMarketplace(
            GetMarketplaceRequest.newBuilder()
                                 .setId("daeacba1-0fde-4bd0-9549-b09f008cf41d")
                                 .build()
        );

        assertThat(createResponse.getMarketplace()).isNotEqualTo(getResponse.getMarketplace());
    }

    @Test
    void testGetMarketplaces() {
        long existingRecords = server.getContext()
                                     .getBean(MarketplaceRepository.class)
                                     .count();

        int pageSize = 30;
        int recordsToAdd = 50;
        for (int i = 0; i < recordsToAdd; i++) {
            client.createMarketplace(MarketplaceDto.newBuilder()
                                                   .setName("Organic Whole Wheat")
                                                   .setDescription("Whole Wheat")
                                                   .setType("Raw Ingredients")
                                                   .setIsAvailable(true)
                                                   .setQuantity(20)
                                                   .setQuantityUnit("LBS")
                                                   .setPrice(100F)
                                                   .setOriginalPrice(200F)
                                                   .setLatitude(38.897147)
                                                   .setLongitude(-77.043934)
                                                   .setDistance("")
                                                   .setWasteProbability(2.5F)
                                                   .setPurchasedDate("")
                                                   .setPurchasedBy("")
                                                   .setLocation("USA")
                                                   .setAvailableDate("01/01/2021")
                                                   .setPriceIncrease(25.0F)
                                                   .setRating(3.5F)
                                                   .addAllImages(images)
                                                   .setSku(UUID.randomUUID().toString())
                                                   .setMinimumBid(35.00F)
                                                   .setReservePrice(30.00F)
                                                   .setBidTimeframe("2 weeks")
                                                   .addAllAllergens(allergens)
                                                   .setPriceUnit("$")
                                                   .setAutoPricing(true)
                                                   .setExpiryDate("01/08/2021")
                                                   .build());
        }

        GetMarketplacesResponse firstPageResponse = client.getMarketplaces(GetMarketplacesRequest.newBuilder()
                                                                                                 .setPageSize(pageSize)
                                                                                                 .setStartPage(0)
                                                                                                 .build()
        );

        assertThat(firstPageResponse.getTotalElements()).isEqualTo(existingRecords + recordsToAdd);
        assertThat(firstPageResponse.getHasNext()).isTrue();
        assertThat(firstPageResponse.getHasPrevious()).isFalse();

        GetMarketplacesResponse lastPageResponse = client.getMarketplaces(GetMarketplacesRequest.newBuilder()
                                                                                                .setPageSize(pageSize)
                                                                                                .setStartPage(firstPageResponse.getTotalPages() - 1)
                                                                                                .build()
        );

        assertThat(lastPageResponse.getHasNext()).isFalse();
        assertThat(lastPageResponse.getHasPrevious()).isTrue();
    }

    @Test
    void testPositive_getCreateAndUpdateMarketplace() {
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);

        UpdateMarketplaceResponse updateResponse = client.updateMarketplace(
            MarketplaceDto.newBuilder()
                          .setId(createResponse.getMarketplace()
                                               .getId())
                          .setName("Organic Whole Wheat")
                          .setDescription("Whole Wheat")
                          .setType("Baked Ingredients")
                          .setIsAvailable(true)
                          .setQuantity(20)
                          .setQuantityUnit("LBS")
                          .setPrice(100F)
                          .setOriginalPrice(200F)
                          .setLatitude(38.897147)
                          .setLongitude(-77.043934)
                          .setDistance("2 miles away")
                          .setWasteProbability(2.5F)
                          .setPurchasedDate("02/08/2021")
                          .setPurchasedBy("")
                          .setLocation("CA")
                          .setAvailableDate("02/08/2021")
                          .setPriceIncrease(25.0F)
                          .setRating(3.5F)
                          .addAllImages(images)
                          .setSku(createResponse.getMarketplace().getSku())
                          .setTotalBids(3)
                          .setBidTimeframe("2 weeks")
                          .addAllAllergens(allergens)
                          .setPriceUnit("$")
                          .setAutoPricing(true)
                          .setExpiryDate("02/08/2021")
                          .setStatus("Unavailable")
                          .build()
        );

        assertThat(createResponse.getMarketplace()
                                 .getId()).isEqualTo(updateResponse.getMarketplace()
                                                                   .getId());
    }

    @Test
    void testNegative_getCreateAndUpdateMarketplace() {
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);

        UpdateMarketplaceResponse updateResponse = client.updateMarketplace(
            MarketplaceDto.newBuilder()
                          .setId(StringValue.of("e749335a-1730-11ee-be56-0242ac120002"))
                          .setName("Organic Whole Wheat")
                          .setDescription("Whole Wheat")
                          .setType("Baked Ingredients")
                          .setIsAvailable(true)
                          .setQuantity(20)
                          .setQuantityUnit("LBS")
                          .setPrice(100F)
                          .setOriginalPrice(200F)
                          .setLatitude(38.897147)
                          .setLongitude(-77.043934)
                          .setDistance("2 mile away")
                          .setWasteProbability(2.5F)
                          .setPurchasedDate("02/08/2021")
                          .setPurchasedBy("")
                          .setLocation("CA")
                          .setAvailableDate("")
                          .setPriceIncrease(25.0F)
                          .setRating(3.5F)
                          .addAllImages(images)
                          .setSku(createResponse.getMarketplace().getSku())
                          .setMinimumBid(35.00F)
                          .setReservePrice(30.00F)
                          .setBidTimeframe("2 weeks")
                          .setTotalBids(5)
                          .addAllAllergens(allergens)
                          .setPriceUnit("$")
                          .setAutoPricing(true)
                          .setExpiryDate("02/08/2021")
                          .setStatus("Unavailable")
                          .build()
        );

        assertThat(createResponse.getMarketplace()
                                 .getId()).isNotEqualTo(updateResponse.getMarketplace()
                                                                      .getId());
    }

    @Test
    void test_getCreateAndUpdateMarketplaceWithPurchaseFields() {
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);
        CreateAccountResponse accountResponse = client.createAccount(accountDtoOne);

        UpdateMarketplaceResponse updateResponse = client.updateMarketplace(
            MarketplaceDto.newBuilder()
                          .setId(createResponse.getMarketplace()
                                               .getId())
                          .setPurchasedBy(accountResponse.getAccount()
                                                         .getId()
                                                         .getValue())
                          .build()
        );
        logger.info("createResponse: " + "\n" + createResponse.getMarketplace());
        logger.info("updateResponse: " + "\n" + updateResponse.getMarketplace());
        assertThat(createResponse.getMarketplace()
                                 .getId()).isEqualTo(updateResponse.getMarketplace()
                                                                   .getId());
    }

//    Bid-test-case
    @Test
    void test_getCreateAndUpdateMarketplaceWithBids() {
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);
        CreateAccountResponse accountResponseOne = client.createAccount(accountDtoOne);
        CreateAccountResponse accountResponseTwo = client.createAccount(accountDtoTwo);

        UpdateMarketplaceResponse updateResponseOne = client.updateMarketplace(
            MarketplaceDto.newBuilder()
                          .setId(createResponse.getMarketplace()
                                               .getId())
                          .setHighestBid(50.00F)
                          .setBidderId(accountResponseOne.getAccount().getId().getValue())
                          .build()
        );

        UpdateMarketplaceResponse updateResponseTwo = client.updateMarketplace(
            MarketplaceDto.newBuilder()
                          .setId(createResponse.getMarketplace()
                                               .getId())
                          .setBidderId(accountResponseTwo.getAccount().getId().getValue())
                          .setHighestBid(75.00F)
                          .build()
        );
        logger.info("createResponse: " + "\n" + createResponse.getMarketplace());
        logger.info("updateResponseOne: " + "\n" + updateResponseOne.getMarketplace().toString());
        logger.info("updateResponseTwo: " + "\n" + updateResponseTwo.getMarketplace().toString());

        assertThat(createResponse.getMarketplace()
                                 .getId()).isEqualTo(updateResponseOne.getMarketplace()
                                                                   .getId());

        assertThat(createResponse.getMarketplace()
                                 .getId()).isEqualTo(updateResponseTwo.getMarketplace()
                                                                      .getId());
    }

    @Test
    void testPositive_deleteMarketplace(){
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);
        DeleteMarketplaceResponse response = client.deleteMarketplace(
            DeleteMarketplaceRequest.newBuilder()
                                    .setId(createResponse.getMarketplace().getId().getValue())
                                    .build());

        assertThat(createResponse.getMarketplace().getId()).isEqualTo(response.getMarketplace().getId());
    }

    @Test
    void test_updateMarketplaceWithSameImagesAndAllergens(){
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);
        UpdateMarketplaceResponse updateResponse = client.updateMarketplace(
            MarketplaceDto.newBuilder()
                          .setId(createResponse.getMarketplace()
                                               .getId())
                          .addAllImages(images)
                          .addAllAllergens(allergens)
                          .build()
        );

        assertThat(createResponse.getMarketplace().getImagesList()).isEqualTo(updateResponse.getMarketplace().getImagesList());
        assertThat(createResponse.getMarketplace().getImagesCount()).isEqualTo(updateResponse.getMarketplace().getImagesCount());
        assertThat(createResponse.getMarketplace().getAllergensList()).isEqualTo(updateResponse.getMarketplace().getAllergensList());
        assertThat(createResponse.getMarketplace().getAllergensCount()).isEqualTo(updateResponse.getMarketplace().getAllergensCount());


    }

    @Test
    void test_updateMarketplaceWithNewImagesAndAllergens(){
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);

        List<String> newAllergens = List.of("Gluten", "Gluten","Gluten", "Fungus");
        List<String> newImages = List.of("image2.png", "image3.png", images.get(0));
        UpdateMarketplaceResponse updateResponse = client.updateMarketplace(
            MarketplaceDto.newBuilder()
                          .setId(createResponse.getMarketplace()
                                               .getId())
                          .addAllImages(newImages)
                          .addAllAllergens(newAllergens)
                          .build()
        );

        assertThat(createResponse.getMarketplace().getImagesList()).isNotEqualTo(updateResponse.getMarketplace().getImagesList());
        assertThat(createResponse.getMarketplace().getImagesCount()).isNotEqualTo(updateResponse.getMarketplace().getImagesCount());
        assertThat(createResponse.getMarketplace().getAllergensList()).isNotEqualTo(updateResponse.getMarketplace().getAllergensList());
        assertThat(createResponse.getMarketplace().getAllergensCount()).isNotEqualTo(updateResponse.getMarketplace().getAllergensCount());


    }

    @Test
    void testNegative_deleteMarketplace(){
        CreateMarketplaceResponse createResponse = client.createMarketplace(marketplaceDto);
        DeleteMarketplaceResponse response = client.deleteMarketplace(
            DeleteMarketplaceRequest.newBuilder()
                                    .setId("daeacba1-0fde-4bd0-9549-b09f008cf41d")
                                    .build());

        assertThat(createResponse.getMarketplace().getId()).isNotEqualTo(response.getMarketplace().getId());
    }

    @Test
    void test_CreateAccount() {
        CreateAccountResponse accountResponse = client.createAccount(accountDtoOne);
        logger.info("accountResponse: " + "\n" + accountResponse.getAccount().toString());
    }

    @Test
    void testPositive_getCreateAndGetAccount() {
        CreateAccountResponse createResponse = client.createAccount(accountDtoOne);

        GetAccountResponse getResponse = client.getAccount(
            GetAccountRequest.newBuilder()
                             .setId(createResponse
                                 .getAccount()
                                 .getId()
                                 .getValue())
                             .build()
        );

        assertThat(createResponse.getAccount()).isEqualTo(getResponse.getAccount());
    }

    @Test
    void testNegative_getCreateAndGetAccount() {
        CreateAccountResponse createResponse = client.createAccount(accountDtoOne);

        GetAccountResponse getResponse = client.getAccount(
            GetAccountRequest.newBuilder()
                             .setId("daeacba1-0fde-4bd0-9549-b09f008cf41d")
                             .build()
        );

        assertThat(createResponse.getAccount()).isNotEqualTo(getResponse.getAccount());
    }

    @Test
    void testNegative_getCreateAndUpdateAccount() {
        CreateAccountResponse createResponse = client.createAccount(accountDtoOne);

        UpdateAccountResponse updateResponse = client.updateAccount(
            AccountDto.newBuilder()
                      .setId(createResponse
                          .getAccount()
                          .getId())
                      .setName("INFOSYS")
                      .setImageUrl("https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Infosys_logo.svg/400px-Infosys_logo.svg.png?20100302211036")
                      .setLatitude(38.897147)
                      .setLongitude(-77.043934)
                      .setPurchasedStat(0)
                      .setMoneySavedStat(0)
                      .setWasteSavedStat(0)
                      .build()
        );

        assertThat(createResponse.getAccount()
                                 .getId()).isEqualTo(updateResponse.getAccount()
                                                                   .getId());
    }

    @Test
    void testPositive_getCreateAndUpdateAccount() {
        CreateAccountResponse createResponse = client.createAccount(accountDtoOne);

        UpdateAccountResponse updateResponse = client.updateAccount(
            AccountDto.newBuilder()
                      .setId(StringValue.of("e749335a-1730-11ee-be56-0242ac120002"))
                      .setName("INFOSYS")
                      .setImageUrl("https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Infosys_logo.svg/400px-Infosys_logo.svg.png?20100302211036")
                      .setLatitude(38.897147)
                      .setLongitude(-77.043934)
                      .setPurchasedStat(0)
                      .setMoneySavedStat(0)
                      .setWasteSavedStat(0)
                      .build()
        );

        assertThat(createResponse.getAccount()
                                 .getId()).isNotEqualTo(updateResponse.getAccount()
                                                                      .getId());
    }


    @Test
    void testGetAccounts() {
        long existingRecords = server.getContext()
                                     .getBean(AccountRepository.class)
                                     .count();

        int pageSize = 10;
        int recordsToAdd = 20;
        for (int i = 0; i < recordsToAdd; i++) {
            client.createAccount(AccountDto.newBuilder()
                                           .setName("INFOSYS" + i)
                                           .setImageUrl("https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Infosys_logo.svg/400px-Infosys_logo.svg.png?20100302211036")
                                           .setLatitude(38.897147)
                                           .setLongitude(-77.043934)
                                           .setPurchasedStat(0)
                                           .setMoneySavedStat(0)
                                           .setWasteSavedStat(0)
                                           .build());
        }

        GetAccountsResponse firstPageResponse = client.getAccounts(GetAccountsRequest.newBuilder()
                                                                                     .setPageSize(pageSize)
                                                                                     .setStartPage(0)
                                                                                     .build()
        );

        assertThat(firstPageResponse.getTotalElements()).isEqualTo(existingRecords + recordsToAdd);
        assertThat(firstPageResponse.getHasNext()).isTrue();
        assertThat(firstPageResponse.getHasPrevious()).isFalse();

        GetAccountsResponse lastPageResponse = client.getAccounts(GetAccountsRequest.newBuilder()
                                                                                    .setPageSize(pageSize)
                                                                                    .setStartPage(firstPageResponse.getTotalPages() - 1)
                                                                                    .build()
        );

        assertThat(lastPageResponse.getHasNext()).isFalse();
        assertThat(lastPageResponse.getHasPrevious()).isTrue();
    }

    @Test
    void testGetIngredients(){
        byte[] imageBytes = null;
        String IMAGE_URL = "https://imageupload.io/ib/sEEYSh3nYTw1aRy_1691661515.jpg";

        try {
            imageBytes = IOUtils.toByteArray(new URL(IMAGE_URL));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        String imageBase64 = new String(Base64.encodeBase64(imageBytes), StandardCharsets.UTF_8);

        GetIngredientsRequest request = GetIngredientsRequest.newBuilder()
                                                             .setImage(imageBase64)
                                                             .build();
        GetIngredientsResponse getIngredientsResponse = client.getIngredients(request);
        logger.info("\n" + "Ingredient List: ");
        getIngredientsResponse.getIngredientList().stream().forEach(System.out::println);
    }
}
