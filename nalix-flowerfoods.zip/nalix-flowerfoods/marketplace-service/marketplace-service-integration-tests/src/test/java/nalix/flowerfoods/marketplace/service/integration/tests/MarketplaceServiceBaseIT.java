package nalix.flowerfoods.marketplace.service.integration.tests;


import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import nalix.flowerfoods.marketplace.service.client.MarketplaceServiceClient;
import nalix.flowerfoods.marketplace.service.integration.tests.config.IntegrationTestsConfig;
import nalix.flowerfoods.marketplace.service.server.MarketplaceServiceServer;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = { IntegrationTestsConfig.class })
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MarketplaceServiceBaseIT {
    @Autowired
    protected MarketplaceServiceServer server;

    @Autowired
    protected MarketplaceServiceClient client;
}