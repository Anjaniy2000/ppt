package nalix.flowerfoods.marketplace.service.integration.tests.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import nalix.flowerfoods.marketplace.service.client.MarketplaceServiceClient;
import nalix.flowerfoods.marketplace.service.server.MarketplaceServiceServer;


@Configuration
public class IntegrationTestsConfig {
    

    @Bean(initMethod = "start", destroyMethod = "stop")
    public MarketplaceServiceServer marketplaceServiceServer() {
         return new MarketplaceServiceServer()
                .withRandomPorts()
                .withTempDb();
    }

    @Bean
    public MarketplaceServiceClient marketplaceServiceClient(MarketplaceServiceServer server) {
        return MarketplaceServiceClient.of("localhost", server.getGrpcPort());
    }
}
