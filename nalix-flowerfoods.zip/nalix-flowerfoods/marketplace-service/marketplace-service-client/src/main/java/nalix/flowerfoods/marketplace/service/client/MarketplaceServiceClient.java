package nalix.flowerfoods.marketplace.service.client;

import io.grpc.ManagedChannelBuilder;
import nalix.flowerfoods.marketplace.service.api.v1.MarketplaceService;
import nalix.flowerfoods.marketplace.service.grpc.v1.*;

public class MarketplaceServiceClient implements MarketplaceService {
    MarketplaceServiceGrpc.MarketplaceServiceBlockingStub stub;

    public static MarketplaceServiceClient of (String host, int port) {
        return new MarketplaceServiceClient(ManagedChannelBuilder.forAddress(host, port).usePlaintext().maxInboundMessageSize(Integer.MAX_VALUE));
    }

    private MarketplaceServiceClient (ManagedChannelBuilder<?> channelBuilder) {
        this.stub = MarketplaceServiceGrpc.newBlockingStub(channelBuilder.maxInboundMessageSize(Integer.MAX_VALUE).build());
    }

    @Override
    public CreateMarketplaceResponse createMarketplace (MarketplaceDto marketplace) {
        return stub.createMarketplace(marketplace);
    }

    @Override
    public GetMarketplacesResponse getMarketplaces (GetMarketplacesRequest request) {
        return stub.getMarketplaces(request);
    }

    @Override
    public GetMarketplaceResponse getMarketplace (GetMarketplaceRequest request) {
        return stub.getMarketplace(request);
    }

    @Override
    public UpdateMarketplaceResponse updateMarketplace (MarketplaceDto marketplace) {
        return stub.updateMarketplace(marketplace);
    }

    @Override
    public CreateAccountResponse createAccount (AccountDto account) {
        return stub.createAccount(account);
    }

    @Override
    public GetAccountsResponse getAccounts (GetAccountsRequest request) {
        return stub.getAccounts(request);
    }

    @Override
    public GetAccountResponse getAccount (GetAccountRequest request) {
        return stub.getAccount(request);
    }

    @Override
    public UpdateAccountResponse updateAccount (AccountDto account) {
        return stub.updateAccount(account);
    }

    @Override
    public GetIngredientsResponse getIngredients (GetIngredientsRequest getIngredientsRequest) {
        return stub.getIngredients(getIngredientsRequest);
    }

    @Override
    public DeleteMarketplaceResponse deleteMarketplace(DeleteMarketplaceRequest request) {
        return stub.deleteMarketplace(request);
    }

}
