# marketplace-service-client

## Dependency

```xml
    <dependency>
        <groupId>nalix.flowerfoods</groupId>
        <artifactId>marketplace-service-client</artifactId>
    </dependency>
```