package nalix.flowerfoods.marketplace.service.api.v1;

import nalix.flowerfoods.marketplace.service.grpc.v1.*;

public interface MarketplaceService {
    CreateMarketplaceResponse createMarketplace (MarketplaceDto marketplace);
    GetMarketplacesResponse getMarketplaces (GetMarketplacesRequest request);
    GetMarketplaceResponse getMarketplace (GetMarketplaceRequest request);
    UpdateMarketplaceResponse updateMarketplace (MarketplaceDto marketplace);
    CreateAccountResponse createAccount (AccountDto account);
    GetAccountsResponse getAccounts (GetAccountsRequest request);
    GetAccountResponse getAccount (GetAccountRequest request);
    UpdateAccountResponse updateAccount (AccountDto account);
    GetIngredientsResponse getIngredients (GetIngredientsRequest getIngredientsRequest);
    DeleteMarketplaceResponse deleteMarketplace (DeleteMarketplaceRequest request);
}
