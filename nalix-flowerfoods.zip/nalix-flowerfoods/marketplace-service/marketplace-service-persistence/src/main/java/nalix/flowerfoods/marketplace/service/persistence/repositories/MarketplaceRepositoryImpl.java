package nalix.flowerfoods.marketplace.service.persistence.repositories;

import com.querydsl.core.types.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import nalix.flowerfoods.marketplace.service.persistence.entities.MarketplaceEntity;
import nalix.flowerfoods.marketplace.service.persistence.entities.QMarketplaceEntity;

public class MarketplaceRepositoryImpl implements MarketplaceRepositoryExtensions {

    @Autowired
    MarketplaceRepository marketplaceRepository;

    @Override
    public Page<MarketplaceEntity> findByNameQueryDsl(String name, Pageable pageable) {
        QMarketplaceEntity qm = QMarketplaceEntity.marketplaceEntity;
        Predicate predicate = qm.name.eq(name);
        return marketplaceRepository.findAll(predicate, pageable);
    }
}
