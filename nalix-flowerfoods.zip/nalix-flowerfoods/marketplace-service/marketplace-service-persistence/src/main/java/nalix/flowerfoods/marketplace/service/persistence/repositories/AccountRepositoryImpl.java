package nalix.flowerfoods.marketplace.service.persistence.repositories;

import com.querydsl.core.types.Predicate;
import nalix.flowerfoods.marketplace.service.persistence.entities.AccountEntity;
import nalix.flowerfoods.marketplace.service.persistence.entities.QAccountEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public class AccountRepositoryImpl implements AccountRepositoryExtensions{

    @Autowired
    AccountRepository accountRepository;
    @Override
    public Page<AccountEntity> findByNameQueryDsl(String name, Pageable pageable) {
        QAccountEntity qAccount = QAccountEntity.accountEntity;
        Predicate predicate = qAccount.name.eq(name);
        return accountRepository.findAll(predicate, pageable);
    }
}
