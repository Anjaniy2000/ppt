package nalix.flowerfoods.marketplace.service.persistence.repositories;

import nalix.flowerfoods.marketplace.service.persistence.entities.AccountEntity;
import nalix.flowerfoods.marketplace.service.persistence.entities.MarketplaceEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface AccountRepositoryExtensions {
    Page<AccountEntity> findByNameQueryDsl(String name, Pageable pageable);
}
