package nalix.flowerfoods.marketplace.service.persistence.entities;

import io.hypersistence.utils.hibernate.type.array.ListArrayType;
import nalix.flowerfoods.platform.persistence.jpa.AbstractEntity;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import javax.annotation.Nullable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "marketplace")
@TypeDef(name = "list-array", typeClass = ListArrayType.class)
public class MarketplaceEntity extends AbstractEntity {

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "type")
    private String type;

    @Column(name = "is_available")
    private Boolean is_available;

    @Column(name = "quantity")
    private Integer quantity;

    @Column(name = "quantity_unit")
    private String quantity_unit;

    @Column(name = "price")
    private Float price;

    @Column(name = "original_price")
    private Float original_price;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "distance")
    private String distance;

    @Column(name = "waste_probability")
    private Float waste_probability;

    @Column(name = "purchased_by")
    private UUID purchased_by;

    @Column(name = "purchased_date")
    private Date purchased_date;

    @Column(name = "location")
    private String location;

    @Column(name = "available_date")
    private String available_date;

    @Column(name = "price_increase")
    private Float price_increase;

    @Column(name = "rating")
    private Float rating;

    @Type(type = "list-array")
    @Column(
        name = "images",
        columnDefinition = "text[]"
    )
    private List<String> images;

    @Column(name = "sku")
    private String sku;

    @Column(name = "minimum_bid")
    private Float minimum_bid;

    @Column(name = "reserve_price")
    private Float reserve_price;

    @Column(name = "bid_timeframe")
    private String bid_timeframe;

    @Column(name = "bidder_id")
    private UUID bidder_id;

    @Column(name = "total_bids")
    private Integer total_bids;

    @Column(name = "highest_bid")
    private Float highest_bid;

    @Type(type = "list-array")
    @Column(
        name = "allergens",
        columnDefinition = "text[]"
    )
    private List<String> allergens;

    @Column(name = "price_unit")
    private String price_unit;

    @Column(name = "auto_pricing")
    private Boolean auto_pricing;

    @Column(name = "status")
    private String status;

    @Column(name = "expiry_date")
    private String expiry_date;


    // Hibernate requires a default constructor
    public MarketplaceEntity() {}

    public MarketplaceEntity(@NotNull UUID id,
                             @NotNull String name,
                             @NotNull String description,
                             @NotNull String type,
                             @NotNull Boolean is_available,
                             @NotNull Integer quantity,
                             @NotNull String quantity_unit,
                             @NotNull Float price,
                             @NotNull Float original_price,
                             @NotNull Double latitude,
                             @NotNull Double longitude,
                             @Nullable String distance,
                             @NotNull Float waste_probability,
                             @Nullable UUID purchased_by,
                             @Nullable Date purchased_date,
                             @NotNull String location,
                             @NotNull String available_date,
                             @NotNull Float price_increase,
                             @NotNull Float rating,
                             @NotNull List<String> images,
                             @NotNull String sku,
                             @NotNull Float minimum_bid,
                             @NotNull Float reserve_price,
                             @NotNull String bid_timeframe,
                             @NotNull Integer total_bids,
                             @NotNull Float highest_bid,
                             @Nullable UUID bidder_id,
                             @NotNull List<String> allergens,
                             @NotNull String price_unit,
                             @NotNull Boolean auto_pricing,
                             @NotNull String status,
                             @NotNull String expiry_date) {
        setId(id);
        this.name = name;
        this.description = description;
        this.type = type;
        this.is_available = is_available;
        this.quantity = quantity;
        this.quantity_unit = quantity_unit;
        this.price = price;
        this.original_price = original_price;
        this.latitude = latitude;
        this.longitude = longitude;
        this.distance = distance;
        this.waste_probability = waste_probability;
        this.purchased_by = purchased_by;
        this.purchased_date = purchased_date;
        this.location = location;
        this.available_date = available_date;
        this.price_increase = price_increase;
        this.rating = rating;
        this.images = images;
        this.sku = sku;
        this.minimum_bid = minimum_bid;
        this.reserve_price = reserve_price;
        this.bid_timeframe = bid_timeframe;
        this.total_bids = total_bids;
        this.highest_bid = highest_bid;
        this.bidder_id = bidder_id;
        this.allergens = allergens;
        this.price_unit = price_unit;
        this.auto_pricing = auto_pricing;
        this.status = status;
        this.expiry_date = expiry_date;
    }

    public String getName() {
        return name;
    }

    public void setName(@NotNull String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(@NotNull String type) {
        this.type = type;
    }

    public Boolean getIs_available() {
        return is_available;
    }

    public void setIs_available(Boolean is_available) {
        this.is_available = is_available;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(@NotNull Integer quantity) {
        this.quantity = quantity;
    }

    public String getQuantity_unit() {
        return quantity_unit;
    }

    public void setQuantity_unit(@NotNull String quantity_unit) {
        this.quantity_unit = quantity_unit;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Float getOriginal_price() {
        return original_price;
    }

    public void setOriginal_price(Float original_price) {
        this.original_price = original_price;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public Float getWaste_probability() {
        return waste_probability;
    }

    public void setWaste_probability(@NotNull Float waste_probability) {
        this.waste_probability = waste_probability;
    }

    public UUID getPurchased_by() {
        return purchased_by;
    }

    public void setPurchased_by(@NotNull UUID purchased_by) {
        this.purchased_by = purchased_by;
    }

    public Date getPurchased_date() {
        return purchased_date;
    }

    public void setPurchased_date(@NotNull Date purchased_date) {
        this.purchased_date = purchased_date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getAvailable_date() {
        return available_date;
    }

    public void setAvailable_date(String available_date) {
        this.available_date = available_date;
    }

    public Float getPrice_increase() {
        return price_increase;
    }

    public void setPrice_increase(Float price_increase) {
        this.price_increase = price_increase;
    }

    public Float getRating() {
        return rating;
    }

    public void setRating(Float rating) {
        this.rating = rating;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public Float getMinimum_bid() {
        return minimum_bid;
    }

    public void setMinimum_bid(Float minimum_bid) {
        this.minimum_bid = minimum_bid;
    }

    public Float getReserve_price() {
        return reserve_price;
    }

    public void setReserve_price(Float reserve_price) {
        this.reserve_price = reserve_price;
    }

    public String getBid_timeframe() {
        return bid_timeframe;
    }

    public void setBid_timeframe(String bid_timeframe) {
        this.bid_timeframe = bid_timeframe;
    }

    public Integer getTotal_bids() {
        return total_bids;
    }

    public void setTotal_bids(Integer total_bids) {
        this.total_bids = total_bids;
    }

    public Float getHighest_bid() {
        return highest_bid;
    }

    public void setHighest_bid(Float highest_bid) {
        this.highest_bid = highest_bid;
    }

    public UUID getBidder_id() {
        return bidder_id;
    }

    public void setBidder_id(UUID bidder_id) {
        this.bidder_id = bidder_id;
    }

    public List<String> getAllergens() {
        return allergens;
    }

    public void setAllergens(List<String> allergens) {
        this.allergens = allergens;
    }

    public String getPrice_unit() {
        return price_unit;
    }

    public void setPrice_unit(String price_unit) {
        this.price_unit = price_unit;
    }

    public Boolean getAuto_pricing() {
        return auto_pricing;
    }

    public void setAuto_pricing(Boolean auto_pricing) {
        this.auto_pricing = auto_pricing;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getExpiry_date() {
        return expiry_date;
    }

    public void setExpiry_date(String expiry_date) {
        this.expiry_date = expiry_date;
    }

    @Override
    public String toString() {
        return "MarketplaceEntity{" +
            "id='" + getId() + '\'' +
            "name='" + name + '\'' +
            ", description='" + description + '\'' +
            ", type='" + type + '\'' +
            ", is_available=" + is_available +
            ", quantity=" + quantity +
            ", quantity_unit='" + quantity_unit + '\'' +
            ", price=" + price +
            ", original_price=" + original_price +
            ", latitude=" + latitude +
            ", longitude=" + longitude +
            ", distance='" + distance + '\'' +
            ", waste_probability=" + waste_probability +
            ", purchased_by=" + purchased_by +
            ", purchased_date=" + purchased_date +
            ", location='" + location + '\'' +
            ", available_date='" + available_date + '\'' +
            ", price_increase=" + price_increase +
            ", rating=" + rating +
            ", images=" + images +
            ", sku='" + sku + '\'' +
            ", minimum_bid=" + minimum_bid +
            ", reserve_price=" + reserve_price +
            ", bid_timeframe='" + bid_timeframe + '\'' +
            ", bidder_id=" + bidder_id +
            ", total_bids=" + total_bids +
            ", highest_bid=" + highest_bid +
            ", allergens=" + allergens +
            ", price_unit='" + price_unit + '\'' +
            ", auto_pricing=" + auto_pricing +
            ", status='" + status + '\'' +
            ", expiry_date='" + expiry_date + '\'' +
            '}';
    }
}
