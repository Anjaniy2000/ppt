package nalix.flowerfoods.marketplace.service.persistence.repositories;

import nalix.flowerfoods.marketplace.service.persistence.entities.MarketplaceEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.UUID;

/**
 * @author Archetect
 */
@Repository
public interface MarketplaceRepository extends
    JpaRepository<MarketplaceEntity, UUID>,
    QuerydslPredicateExecutor<MarketplaceEntity>,
    MarketplaceRepositoryExtensions
{

    @Query(value = "SELECT * FROM marketplace m WHERE " +
        "(m.is_available = :is_available)" +
        "AND" +
        "(:name = '' OR m.name = :name) " +
        "AND " +
        "(:type = '' OR m.type = :type) ", nativeQuery = true)
    Page<MarketplaceEntity> getMarketplaces(@Param("name") String name,
                                            @Param("type") String type,
                                            @Param("is_available") Boolean is_available,
                                            Pageable pageable);

}
