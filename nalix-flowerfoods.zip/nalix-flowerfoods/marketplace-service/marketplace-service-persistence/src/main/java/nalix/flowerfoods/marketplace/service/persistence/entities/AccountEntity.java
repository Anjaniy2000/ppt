package nalix.flowerfoods.marketplace.service.persistence.entities;

import nalix.flowerfoods.platform.persistence.jpa.AbstractEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@Entity
@Table(name = "account")
public class AccountEntity extends AbstractEntity {
    @Column(name = "name")
    private String name;

    @Column(name = "email")
    private String email;

    @Column(name = "image_url")
    private String image_url;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "purchased_stat")
    private Float purchased_stat;

    @Column(name = "money_saved_stat")
    private Float money_saved_stat;

    @Column(name = "waste_saved_stat")
    private Float waste_saved_stat;

    // Hibernate requires a default constructor
    public AccountEntity() {
    }

    public AccountEntity(@NotNull UUID id,
                         @NotNull String name,
                         @NotNull String email,
                         @NotNull String image_url,
                         @NotNull Double latitude,
                         @NotNull Double longitude,
                         @NotNull Float purchased_stat,
                         @NotNull Float money_saved_stat,
                         @NotNull Float waste_saved_stat) {

        setId(id);
        this.name = name;
        this.email = email;
        this.image_url = image_url;
        this.latitude = latitude;
        this.longitude = longitude;
        this.purchased_stat = purchased_stat;
        this.money_saved_stat = money_saved_stat;
        this.waste_saved_stat = waste_saved_stat;
    }

    public String getName() {
        return name;
    }

    public void setName(@NotNull String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(@NotNull String email) {
        this.email = email;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(@NotNull String image_url) {
        this.image_url = image_url;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
    public Float getPurchased_stat() {
        return purchased_stat;
    }

    public void setPurchased_stat(Float purchased_stat) {
        this.purchased_stat = purchased_stat;
    }

    public Float getMoney_saved_stat() {
        return money_saved_stat;
    }

    public void setMoney_saved_stat(Float money_saved_stat) {
        this.money_saved_stat = money_saved_stat;
    }

    public Float getWaste_saved_stat() {
        return waste_saved_stat;
    }

    public void setWaste_saved_stat(Float waste_saved_stat) {
        this.waste_saved_stat = waste_saved_stat;
    }

    @Override
    public String toString() {
        return "AccountEntity{" +
            "id='" + getId() + '\'' +
            "name='" + name + '\'' +
            ", email='" + email + '\'' +
            ", image_url='" + image_url + '\'' +
            ", latitude=" + latitude +
            ", longitude=" + longitude +
            ", purchased_stat=" + purchased_stat +
            ", money_saved_stat=" + money_saved_stat +
            ", waste_saved_stat=" + waste_saved_stat +
            '}';
    }
}
