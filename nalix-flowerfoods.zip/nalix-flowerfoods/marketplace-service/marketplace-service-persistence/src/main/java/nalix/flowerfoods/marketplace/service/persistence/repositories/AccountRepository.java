package nalix.flowerfoods.marketplace.service.persistence.repositories;

import nalix.flowerfoods.marketplace.service.persistence.entities.AccountEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import java.util.UUID;

public interface AccountRepository extends
    JpaRepository<AccountEntity, UUID>,
    QuerydslPredicateExecutor<AccountEntity>,
    AccountRepositoryExtensions {
    @Query(value = "SELECT * FROM account m WHERE " +
        "(:name = '' OR m.name = :name) " +
        "AND " +
        "(:email = '' OR m.email = :email) " +
        "AND " +
        "(:image_url = '' OR m.image_url = :image_url) ", nativeQuery = true)
    Page<AccountEntity> getAccounts(@Param("name") String name,
                                            @Param("email") String type,
                                            @Param("image_url") String location,
                                            Pageable pageable);

}
