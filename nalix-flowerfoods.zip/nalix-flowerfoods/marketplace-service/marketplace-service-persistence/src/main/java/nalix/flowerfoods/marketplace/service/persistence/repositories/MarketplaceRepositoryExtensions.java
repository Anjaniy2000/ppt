package nalix.flowerfoods.marketplace.service.persistence.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import nalix.flowerfoods.marketplace.service.persistence.entities.MarketplaceEntity;

/**
 * Extensions to the {@link MarketplaceRepository}.  This allows for concrete implementation in the
 * {@link MarketplaceRepositoryImpl} using QueryDSL or with a native EntityManager.
 */
public interface MarketplaceRepositoryExtensions {

    Page<MarketplaceEntity> findByNameQueryDsl(String name, Pageable pageable);
}
