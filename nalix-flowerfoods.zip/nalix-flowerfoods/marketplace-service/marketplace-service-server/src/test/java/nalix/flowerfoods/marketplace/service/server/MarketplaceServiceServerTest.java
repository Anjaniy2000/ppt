package nalix.flowerfoods.marketplace.service.server;

import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.*;

public class MarketplaceServiceServerTest {

}