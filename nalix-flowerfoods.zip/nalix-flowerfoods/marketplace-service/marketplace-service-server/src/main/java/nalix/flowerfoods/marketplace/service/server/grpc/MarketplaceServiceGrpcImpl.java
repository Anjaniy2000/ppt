package nalix.flowerfoods.marketplace.service.server.grpc;

import io.grpc.stub.StreamObserver;
import org.lognet.springboot.grpc.GRpcService;
import nalix.flowerfoods.marketplace.service.core.MarketplaceServiceCore;
import nalix.flowerfoods.marketplace.service.grpc.v1.*;
import nalix.flowerfoods.marketplace.service.grpc.v1.MarketplaceServiceGrpc.MarketplaceServiceImplBase;

@GRpcService
public class MarketplaceServiceGrpcImpl extends MarketplaceServiceImplBase {

    private final MarketplaceServiceCore service;

    public MarketplaceServiceGrpcImpl(MarketplaceServiceCore service) {
        this.service = service;
    }

    @Override
    public void createMarketplace(MarketplaceDto request, StreamObserver<CreateMarketplaceResponse> responseObserver){
        CreateMarketplaceResponse marketplaceResponse = service.createMarketplace(request);
        responseObserver.onNext(marketplaceResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void getMarketplace(GetMarketplaceRequest request, StreamObserver<GetMarketplaceResponse> responseObserver) {
        GetMarketplaceResponse response = service.getMarketplace(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getMarketplaces(GetMarketplacesRequest request, StreamObserver<GetMarketplacesResponse> responseObserver) {
        GetMarketplacesResponse response = service.getMarketplaces(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void updateMarketplace(MarketplaceDto request, StreamObserver<UpdateMarketplaceResponse> responseObserver) {
        UpdateMarketplaceResponse response = service.updateMarketplace(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void createAccount(AccountDto request, StreamObserver<CreateAccountResponse> responseObserver) {
        CreateAccountResponse response = service.createAccount(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getAccounts(GetAccountsRequest request, StreamObserver<GetAccountsResponse> responseObserver) {
        GetAccountsResponse response = service.getAccounts(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getAccount(GetAccountRequest request, StreamObserver<GetAccountResponse> responseObserver) {
        GetAccountResponse response = service.getAccount(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void updateAccount(AccountDto request, StreamObserver<UpdateAccountResponse> responseObserver) {
        UpdateAccountResponse response = service.updateAccount(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getIngredients(GetIngredientsRequest request, StreamObserver<GetIngredientsResponse> responseObserver) {
        GetIngredientsResponse response = service.getIngredients(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void deleteMarketplace(DeleteMarketplaceRequest request, StreamObserver<DeleteMarketplaceResponse> responseObserver) {
        DeleteMarketplaceResponse response = service.deleteMarketplace(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
