package nalix.flowerfoods.marketplace.service.server;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.context.annotation.Import;
import nalix.flowerfoods.marketplace.service.core.MarketplaceServiceCoreConfig;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(
        exclude = {LiquibaseAutoConfiguration.class, DataSourceAutoConfiguration.class}
)
@Import({
        MarketplaceServiceCoreConfig.class,
})
public class MarketplaceServiceServerConfig {

}
