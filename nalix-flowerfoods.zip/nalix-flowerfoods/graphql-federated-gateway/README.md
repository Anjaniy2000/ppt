# nalix flowerfoods GraphQL Federated Gateway

The Graphql Federated Gateway leverages a modified Apollo Federated Gateway Docker image to streamline some of the
configuration.

## Service Setup
1. Update your `registry.yaml` to replace `default-domain-gateway` with the name of your service.
    1. Update the `routing_url` to match domain gateway's the service name in kubernetes
        1. This is generally `http://{service-name}.{service-name}:8080/graphql`
    2. Update the `automation` section to match your organization and repository name.
    3. Update the `file` to match the name of your subgraph file.
2. [Optional] Enable Auth0 JWT authorization
   1. Uncomment the Auth0 section in the `config/router.yaml` file
   2. Fill in your Auth0 endpoint
3. Work with the Platform Team to get your certificates created
    1. You will need an `us-east-1` Certificate for your cloudfront distribution
        1. .platform/kubernetes/components/edge/cloudfront_with_waf.yaml -> spec.forProvider.viewerCertificate[0].acmCertificateArn
    2. You will need an `us-west-2` Certificate for your ingress
        1. .platform/kubernetes/base/project.yaml -> metadata.annotations."alb.ingress.kubernetes.io/certificate-arn"
    3. _The Platform Team will perform the associated DNS updates for you_
        1. ```yaml
           - name: # Ingress Host
             type: CNAME
             ttl: 3600
             values:
                 - #ALB DNS NAME```
        2. ```yaml
           - name: # Certificate name
             type: CNAME
             ttl: 3600
             values:
                 - # Certificate value```
3. When you add the ARNs to their associated locations and make a deploy, your cloudfront distribution will then come up.
4. Once the cloudfront distribution is up, the final step is to update the dns to support the cloudfront alias.
    1. ```yaml
       - name: # Alternate domain names (from cloudfront)
         type: CNAME
         ttl: 3600
         values:
           - # Distribution domain name (from cloudfront)``` 

## Supergraph Generation

### Pipeline

The Supergraph leveraged by the gateway is created & maintained through automation, fill out
the [`registry.yaml`](./registry.yaml) file to make sure all of your subgraphs are included in the composition.

```yaml
federation_version: 2                       # Apollo Graphql Federation version (Used directly in the config) 
subgraphs:                                  # Map of the subgraphs to be used in the composition 
  default-domain-gateway:                   # Repository name for service
    routing_url: http://default-domain-gateway.domain-gateway:8080/graphql # Kubernetes Service address for deployed service
    automation:
      org: default                          # Github organization name for 'domain-gateway' repository 
      branch: main                          # Branch to pull from
      file: default-domain-gateway.graphql  # File name / path for subgraph
```

### Manually

1. Start relevant Graphql service (domain gateway) and
   use [rover's introspect command](https://www.apollographql.com/docs/rover/commands/subgraphs#subgraph-introspect)
   to create the subgraph file.
  1. `rover subgraph introspect http://localhost:[LOCAL_PORT]/graphql/ > your-domain-gateway.graphql`
  2. Repeat for each subgraph in the composition. If there are services that utilize the same port do not worry, you
     can generate the subgraphs one at a time.
2. Create your supergraph configuration file (`supergraph.yaml`).
  1. Based on the `default-domain-gateway` above we'd have the following. _This is file is created during the
     pipeline for the compose command as well, but is not committed back to the repository to prevent confusion._
     ```yaml
     federation_version: 2
     subgraphs:
       default-domain-gateway:
           routing_url: http://default-domain-gateway.domain-gateway:8080/graphql
           schema:
             file: ./default-domain-gateway.graphql
     ```
3. Run [rover's compose command](https://www.apollographql.com/docs/rover/commands/supergraphs#supergraph-compose)
  1. `rover supergraph compose --elv2-license accept --config ./supergraph.yaml --output supergraph.graphql`